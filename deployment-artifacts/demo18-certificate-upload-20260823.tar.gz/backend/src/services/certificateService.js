const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');

const CERTIFICATE_ROOT = process.env.CERTIFICATE_STORAGE_DIR || '/etc/demo18/certificates';
const NGINX_CONFIG_ROOT = process.env.CERTIFICATE_NGINX_CONFIG_DIR || '/etc/nginx/conf.d/demo18-certificates';
const APP_DIR = process.env.APP_DIR || '/var/www/demo18';
const BACKEND_PORT = process.env.PORT || '3001';

function createError(message, code, status = 400) {
  const error = new Error(message);
  error.code = code;
  error.status = status;
  return error;
}

function hostnameFromDomain(domain) {
  const hostname = new URL(domain).hostname.toLowerCase();
  if (!/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i.test(hostname)) {
    throw createError('证书管理仅支持规范的域名地址', 'CERTIFICATE_DOMAIN_INVALID');
  }
  return hostname;
}

function runOpenSsl(args, message) {
  try {
    return execFileSync('openssl', args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
  } catch {
    throw createError(message, 'CERTIFICATE_INVALID');
  }
}

function certificateNames(certificatePath) {
  const output = runOpenSsl(['x509', '-in', certificatePath, '-noout', '-ext', 'subjectAltName'], '证书链不是有效的 X.509 PEM 文件');
  return [...output.matchAll(/DNS:([^,\s]+)/g)].map((item) => item[1].toLowerCase());
}

function certificateCoversHost(names, hostname) {
  return names.some((name) => name === hostname || (name.startsWith('*.') && hostname.endsWith(name.slice(1)) && hostname.split('.').length === name.split('.').length));
}

function publicKeyFingerprint(command, filePath, extraArgs = []) {
  const output = runOpenSsl([...command, '-in', filePath, ...extraArgs], '证书与私钥格式无效');
  return crypto.createHash('sha256').update(output).digest('hex');
}

function nginxConfig(hostname, certificatePath, keyPath) {
  const proxy = `http://127.0.0.1:${BACKEND_PORT}`;
  const headers = `        proxy_http_version 1.1;\n        proxy_set_header Host $host;\n        proxy_set_header X-Real-IP $remote_addr;\n        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n        proxy_set_header X-Forwarded-Proto $scheme;`;
  return `# Managed by demo18 certificate upload. Do not edit manually.\nserver {\n    listen 80;\n    server_name ${hostname};\n    return 301 https://$host$request_uri;\n}\n\nserver {\n    listen 443 ssl;\n    server_name ${hostname};\n    root ${APP_DIR}/frontend/dist;\n    index index.html;\n    client_max_body_size 20m;\n    ssl_certificate ${certificatePath};\n    ssl_certificate_key ${keyPath};\n    include /etc/letsencrypt/options-ssl-nginx.conf;\n\n    location ^~ /card-covers/ {\n        alias ${APP_DIR}/backend/uploads/share-cards/;\n        limit_except GET HEAD { deny all; }\n        add_header Cache-Control \"public, max-age=86400\" always;\n        add_header X-Content-Type-Options \"nosniff\" always;\n    }\n\n    location = /play {\n        proxy_pass ${proxy}/play;\n${headers}\n    }\n\n    location ~ \"^/card/[A-Za-z0-9_-]{20,128}$\" {\n        proxy_pass ${proxy};\n${headers}\n    }\n\n    location ~ \"^/s/[A-Za-z0-9]{6,8}$\" {\n        proxy_pass ${proxy};\n${headers}\n    }\n\n    location /api/ {\n        proxy_pass ${proxy};\n${headers}\n    }\n\n    location = /health {\n        proxy_pass ${proxy}/health;\n${headers}\n    }\n\n    location ~ \"^/([A-Za-z0-9]{6,8})$\" {\n        rewrite \"^/([A-Za-z0-9]{6,8})$\" /api/short/$1 break;\n        proxy_pass ${proxy};\n${headers}\n    }\n\n    location / {\n        try_files $uri $uri/ /index.html;\n    }\n}\n`;
}

function certificatePaths(hostname) {
  const directory = path.join(CERTIFICATE_ROOT, hostname);
  return {
    directory,
    certificate: path.join(directory, 'fullchain.pem'),
    privateKey: path.join(directory, 'privkey.pem'),
    nginxConfig: path.join(NGINX_CONFIG_ROOT, `${hostname}.conf`),
  };
}

function getCertificateStatus(domain) {
  const hostname = hostnameFromDomain(domain);
  const files = certificatePaths(hostname);
  if (!fs.existsSync(files.certificate) || !fs.existsSync(files.privateKey) || !fs.existsSync(files.nginxConfig)) {
    return { hostname, configured: false };
  }
  const details = runOpenSsl(['x509', '-in', files.certificate, '-noout', '-enddate', '-serial'], '已保存的证书文件无效');
  const expiresAt = (details.match(/notAfter=(.+)/) || [])[1] || '';
  return { hostname, configured: true, expiresAt, certificatePath: files.certificate };
}

function installCertificate(domain, certificateBuffer, privateKeyBuffer) {
  const hostname = hostnameFromDomain(domain);
  if (!certificateBuffer?.length || !privateKeyBuffer?.length) {
    throw createError('请同时上传证书链和私钥文件', 'CERTIFICATE_FILES_REQUIRED');
  }
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'demo18-cert-'));
  const certificateInput = path.join(temporary, 'fullchain.pem');
  const keyInput = path.join(temporary, 'privkey.pem');
  try {
    fs.writeFileSync(certificateInput, certificateBuffer, { mode: 0o600 });
    fs.writeFileSync(keyInput, privateKeyBuffer, { mode: 0o600 });
    runOpenSsl(['x509', '-in', certificateInput, '-noout', '-checkend', '0'], '证书已过期或格式无效');
    runOpenSsl(['pkey', '-in', keyInput, '-noout'], '私钥格式无效或受密码保护');
    const names = certificateNames(certificateInput);
    if (!certificateCoversHost(names, hostname)) {
      throw createError(`证书不包含域名 ${hostname}`, 'CERTIFICATE_DOMAIN_MISMATCH');
    }
    const certificateKey = publicKeyFingerprint(['x509'], certificateInput, ['-pubkey', '-noout']);
    const privateKey = publicKeyFingerprint(['pkey'], keyInput, ['-pubout']);
    if (certificateKey !== privateKey) {
      throw createError('证书链与私钥不匹配', 'CERTIFICATE_KEY_MISMATCH');
    }
    const files = certificatePaths(hostname);
    fs.mkdirSync(files.directory, { recursive: true, mode: 0o700 });
    fs.mkdirSync(NGINX_CONFIG_ROOT, { recursive: true, mode: 0o755 });
    const certificateTemp = `${files.certificate}.new`;
    const keyTemp = `${files.privateKey}.new`;
    const configTemp = `${files.nginxConfig}.new`;
    fs.writeFileSync(certificateTemp, certificateBuffer, { mode: 0o644 });
    fs.writeFileSync(keyTemp, privateKeyBuffer, { mode: 0o600 });
    fs.writeFileSync(configTemp, nginxConfig(hostname, files.certificate, files.privateKey), { mode: 0o644 });
    fs.renameSync(certificateTemp, files.certificate);
    fs.renameSync(keyTemp, files.privateKey);
    fs.renameSync(configTemp, files.nginxConfig);
    try {
      execFileSync('nginx', ['-t'], { stdio: 'pipe' });
      execFileSync('systemctl', ['reload', 'nginx'], { stdio: 'pipe' });
    } catch {
      throw createError('Nginx 配置校验失败，证书未启用', 'CERTIFICATE_NGINX_FAILED', 500);
    }
    return { ...getCertificateStatus(domain), names };
  } finally {
    fs.rmSync(temporary, { recursive: true, force: true });
  }
}

module.exports = { getCertificateStatus, installCertificate, createError };
