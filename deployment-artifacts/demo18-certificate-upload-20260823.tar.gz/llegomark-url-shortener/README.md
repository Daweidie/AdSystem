# demo18 Open Graph URL Shortener

这是对 [llegomark/url-shortener](https://github.com/llegomark/url-shortener) 的兼容性改造。原项目作者为 Mark Anthony Llego，原项目及本改造继续保留根目录中的 MIT `LICENSE`；不得在分发时移除该许可证或原作者版权声明。

本 Worker 只承担短码映射、Open Graph HTML 与短期访问缓存。用户、视频、业务组、权限、卡片配置和最终点击统计均以 demo18 MySQL 为准。Worker 不保存也不接触 MySQL 密码。

## 行为

- `GET /:shortCode` 对所有 User-Agent 返回 HTTP 200 完整 HTML，其中含 `og:title`、`og:description`、`og:image`、可见的“继续打开”链接和安全编码的 JavaScript 跳转。
- `POST /api/urls`、`GET /api/urls/:shortCode`、`PUT /api/urls/:shortCode`、`DELETE /api/urls/:shortCode` 使用 `Authorization: Bearer ...` 认证。
- 目标地址在生产配置下必须属于 `ALLOWED_TARGET_ORIGINS`，并指向 `/card/{cardToken}`。
- 旧 KV 记录只要仍含合法 `url` 即可读取；缺少 OG 字段时使用安全默认值。
- 点击先写入 KV 缓存，再通过受保护接口回写 demo18；MySQL 仍是统计事实来源。

## 本地验证

```bash
npm install
npm test
npm run build
npm run deploy -- --dry-run
```

最后一条命令带 `--dry-run`，不会执行生产部署。正式部署前请按 `../docs/cloudflare-og-shortlink-deployment.md` 配置真实 KV ID、密钥和自定义域名，并完成人工变更审批。

## API 示例

```bash
curl -X POST "https://s.hotwharf.com/api/urls" \
  -H "Authorization: Bearer $CLOUDFLARE_SHORTLINK_API_KEY" \
  -H "Content-Type: application/json" \
  --data '{
    "url":"https://vod.zzqixiangkeji.cn/card/abcdefghijklmnopqrstuvwxyz123456",
    "customCode":"abc123",
    "ogTitle":"卡片标题",
    "ogDescription":"卡片简介",
    "ogImage":"https://vod.zzqixiangkeji.cn/cover.jpg",
    "ogUrl":"https://s.hotwharf.com/abc123",
    "expiresIn":86400
  }'
```

API Key 只能由 demo18 后端持有，不能写入前端代码、浏览器存储或日志。

## 微信兼容边界

本方案不需要微信公众号，不使用微信 JS-SDK，通过服务端 Open Graph 元数据实现微信链接预览。微信是否展示简介、最终卡片样式以及刷新时间由微信客户端与其缓存策略决定，本系统不能强制控制。

## License

MIT。详见 [LICENSE](LICENSE) 和 `../docs/dependency-licenses.md`。
