const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const suolinkService = require('../src/services/suolinkService');

async function startServer() {
  let eventualRequests = 0;
  const server = http.createServer((req, res) => {
    if (req.url === '/good') {
      res.writeHead(302, { Location: 'https://vod.hotwharf.com/play?fileId=test' });
      res.end();
      return;
    }

    if (req.url === '/eventual') {
      eventualRequests += 1;
      if (eventualRequests === 1) {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end('<title>404 - 页面不存在</title><link href="e_404.css">');
        return;
      }
      res.writeHead(302, { Location: 'https://vod.hotwharf.com/play?fileId=test' });
      res.end();
      return;
    }

    if (req.url === '/card') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<title>正常的短链卡片</title>');
      return;
    }

    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end('<title>404 - 页面不存在</title>若您长时间无法正常访问建议您扫码联系官方客服');
  });

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  return server;
}

test('Suolink provider URL must use the configured provider domain', () => {
  const shortUrl = suolinkService.normalizeProviderShortUrl(
    'http://w1.hotwharf.com/j458S',
    'w1.hotwharf.com',
    'https://vod.hotwharf.com/play?fileId=test',
    { forceHttps: false },
  );
  assert.equal(shortUrl, 'http://w1.hotwharf.com/j458S');

  assert.throws(
    () => suolinkService.normalizeProviderShortUrl(
      'https://vod.hotwharf.com/AhtYo5zh',
      'w1.hotwharf.com',
      'https://vod.hotwharf.com/play?fileId=test',
    ),
    (error) => error.code === 'SUOLINK_INVALID_RESPONSE',
  );
});

test('Suolink verification accepts redirects and card pages, and retries propagation', async (t) => {
  const server = await startServer();
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const { port } = server.address();
  const origin = `http://127.0.0.1:${port}`;

  const redirect = await suolinkService.verifyShortLink(`${origin}/good`, {
    attempts: 1,
    timeout: 1000,
  });
  assert.equal(redirect.status, 302);

  const card = await suolinkService.verifyShortLink(`${origin}/card`, {
    attempts: 1,
    timeout: 1000,
  });
  assert.equal(card.status, 200);

  const eventual = await suolinkService.verifyShortLink(`${origin}/eventual`, {
    attempts: 2,
    retryDelayMs: 1,
    timeout: 1000,
  });
  assert.equal(eventual.status, 302);
});

test('Suolink verification rejects the provider fake-404 page', async (t) => {
  const server = await startServer();
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const { port } = server.address();

  await assert.rejects(
    suolinkService.verifyShortLink(`http://127.0.0.1:${port}/missing`, {
      attempts: 1,
      timeout: 1000,
    }),
    (error) => error.code === 'SUOLINK_PROVIDER_LINK_INVALID'
      && error.details.reason === 'provider_not_found_page',
  );
});
