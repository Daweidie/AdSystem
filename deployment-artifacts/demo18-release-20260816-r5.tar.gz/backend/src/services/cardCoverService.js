const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const CARD_COVER_DIRECTORY = path.resolve(__dirname, '../../uploads/share-cards');
const CARD_COVER_PUBLIC_PREFIX = '/api/media/share-cards/';
const MAX_CARD_COVER_BYTES = 5 * 1024 * 1024;
const SUPPORTED_TYPES = new Map([
  ['image/jpeg', '.jpg'],
  ['image/png', '.png'],
  ['image/webp', '.webp'],
]);

fs.mkdirSync(CARD_COVER_DIRECTORY, { recursive: true, mode: 0o750 });

function uploadError(message, code = 'CARD_COVER_INVALID', status = 400) {
  const error = new Error(message);
  error.code = code;
  error.status = status;
  return error;
}

const storage = multer.diskStorage({
  destination: CARD_COVER_DIRECTORY,
  filename(req, file, callback) {
    void req;
    callback(null, `${crypto.randomUUID()}${SUPPORTED_TYPES.get(file.mimetype)}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_CARD_COVER_BYTES, files: 1 },
  fileFilter(req, file, callback) {
    void req;
    if (!SUPPORTED_TYPES.has(file.mimetype)) {
      callback(uploadError('卡片图片仅支持 JPG、PNG 或 WebP 格式'));
      return;
    }
    callback(null, true);
  },
}).single('cover');

function uploadCardCover(req, res, next) {
  upload(req, res, (error) => {
    if (!error) {
      next();
      return;
    }
    if (error instanceof multer.MulterError && error.code === 'LIMIT_FILE_SIZE') {
      next(uploadError('卡片图片不能超过 5MB', 'CARD_COVER_TOO_LARGE', 413));
      return;
    }
    next(error);
  });
}

function matchesFileSignature(buffer, mimeType) {
  if (mimeType === 'image/jpeg') {
    return buffer.length >= 3
      && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  }
  if (mimeType === 'image/png') {
    return buffer.length >= 8
      && buffer.subarray(0, 8).equals(Buffer.from('89504e470d0a1a0a', 'hex'));
  }
  if (mimeType === 'image/webp') {
    return buffer.length >= 12
      && buffer.subarray(0, 4).toString('ascii') === 'RIFF'
      && buffer.subarray(8, 12).toString('ascii') === 'WEBP';
  }
  return false;
}

async function validateCardCover(file) {
  if (!file) throw uploadError('请选择要上传的卡片图片');
  const handle = await fs.promises.open(file.path, 'r');
  try {
    const buffer = Buffer.alloc(16);
    const { bytesRead } = await handle.read(buffer, 0, buffer.length, 0);
    if (!matchesFileSignature(buffer.subarray(0, bytesRead), file.mimetype)) {
      throw uploadError('卡片图片内容与文件格式不匹配');
    }
  } finally {
    await handle.close();
  }
}

function publicCardCoverPath(file) {
  return `${CARD_COVER_PUBLIC_PREFIX}${file.filename}`;
}

function managedFilePath(publicPath) {
  const value = String(publicPath || '');
  if (!value.startsWith(CARD_COVER_PUBLIC_PREFIX)) return null;
  const filename = value.slice(CARD_COVER_PUBLIC_PREFIX.length);
  if (!/^[0-9a-f-]{36}\.(jpg|png|webp)$/i.test(filename)) return null;
  const resolved = path.resolve(CARD_COVER_DIRECTORY, filename);
  return path.dirname(resolved) === CARD_COVER_DIRECTORY ? resolved : null;
}

async function removeCardCover(value) {
  const filePath = value?.path || managedFilePath(value);
  if (!filePath) return;
  await fs.promises.rm(filePath, { force: true });
}

module.exports = {
  CARD_COVER_DIRECTORY,
  MAX_CARD_COVER_BYTES,
  uploadCardCover,
  validateCardCover,
  publicCardCoverPath,
  removeCardCover,
};
