const pool = require('../config/db');

async function getConfig(key) {
  const [rows] = await pool.execute(
    'SELECT config_value FROM system_configs WHERE config_key = ? LIMIT 1',
    [key],
  );
  return rows[0]?.config_value || null;
}

async function getEnabledWeChatLandingBaseUrl() {
  const [rows] = await pool.execute(
    `SELECT landing.config_value AS base_url
     FROM system_configs landing
     INNER JOIN system_configs enabled
       ON enabled.config_key = 'wechat_enabled' AND enabled.config_value = '1'
     INNER JOIN domains d
       ON d.domain = landing.config_value
      AND d.type = 'self_hosted'
      AND d.platform = 'self'
      AND d.is_enabled = 1
     WHERE landing.config_key = 'wechat_landing_base_url'
       AND landing.config_value <> ''
     LIMIT 1`,
  );

  return rows[0]?.base_url || null;
}

async function getCustomerBaseUrl() {
  const [domains] = await pool.execute(
    `SELECT d.domain
     FROM domains d
     LEFT JOIN (
       SELECT domain_id, COUNT(*) AS link_count
       FROM short_links
       GROUP BY domain_id
     ) usage_count ON usage_count.domain_id = d.id
     WHERE d.is_enabled = 1 AND d.platform = 'self'
     ORDER BY COALESCE(usage_count.link_count, 0) ASC,
              d.is_primary DESC,
              d.id ASC
     LIMIT 1`,
  );

  return (
    domains[0]?.domain ||
    (await getConfig('customer_base_url')) ||
    process.env.PUBLIC_SHORTLINK_BASE_URL ||
    process.env.PLAY_PAGE_BASE_URL ||
    process.env.FRONTEND_URL ||
    null
  );
}

async function getPlayPageBaseUrl() {
  return (await getEnabledWeChatLandingBaseUrl()) || getCustomerBaseUrl();
}

module.exports = {
  getConfig,
  getCustomerBaseUrl,
  getEnabledWeChatLandingBaseUrl,
  getPlayPageBaseUrl,
};
