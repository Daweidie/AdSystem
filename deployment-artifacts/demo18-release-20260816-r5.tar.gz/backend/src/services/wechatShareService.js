const crypto = require('crypto');
const axios = require('axios');
const pool = require('../config/db');
const { decryptSecret } = require('./secretConfigService');

const TOKEN_URL = 'https://api.weixin.qq.com/cgi-bin/token';
const TICKET_URL = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket';
const CACHE_SAFETY_SECONDS = 300;

let credentialCache = null;
let accessTokenCache = null;
let ticketCache = null;

class WeChatShareError extends Error {
  constructor(message, code = 'WECHAT_SHARE_ERROR', status = 502, details) {
    super(message);
    this.name = 'WeChatShareError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

function validEnvironmentValue(value) {
  const normalized = String(value || '').trim();
  return /^(your_|replace_with_|example|changeme|xxx)/i.test(normalized)
    ? ''
    : normalized;
}

async function getCredentials({ refresh = false } = {}) {
  if (credentialCache && !refresh) return credentialCache;

  const [rows] = await pool.execute(
    `SELECT config_key, config_value FROM system_configs
     WHERE config_key IN (
       'wechat_enabled', 'wechat_landing_base_url', 'wechat_app_id', 'wechat_app_secret'
     )`,
  );
  const config = Object.fromEntries(rows.map((row) => [row.config_key, row.config_value]));
  const storedSecret = config.wechat_app_secret
    ? decryptSecret(config.wechat_app_secret)
    : '';

  credentialCache = {
    enabled: config.wechat_enabled === '1',
    landingBaseUrl: config.wechat_landing_base_url || '',
    appId: config.wechat_app_id || validEnvironmentValue(process.env.WECHAT_APP_ID),
    appSecret: storedSecret || validEnvironmentValue(process.env.WECHAT_APP_SECRET),
  };
  return credentialCache;
}

function clearCache() {
  credentialCache = null;
  accessTokenCache = null;
  ticketCache = null;
}

async function requestWeChat(url, params) {
  let response;
  try {
    response = await axios.get(url, { params, timeout: 8000 });
  } catch (error) {
    throw new WeChatShareError(
      '微信接口暂时不可用，请稍后重试',
      'WECHAT_REQUEST_FAILED',
      502,
    );
  }

  if (!response.data || response.data.errcode) {
    throw new WeChatShareError(
      `微信接口返回错误${response.data?.errcode ? `（${response.data.errcode}）` : ''}`,
      'WECHAT_PROVIDER_ERROR',
      502,
      response.data?.errcode ? { errcode: response.data.errcode } : undefined,
    );
  }
  return response.data;
}

async function getAccessToken(credentials) {
  if (accessTokenCache?.expiresAt > Date.now()) return accessTokenCache.value;
  const data = await requestWeChat(TOKEN_URL, {
    grant_type: 'client_credential',
    appid: credentials.appId,
    secret: credentials.appSecret,
  });
  if (!data.access_token) {
    throw new WeChatShareError('微信未返回 access_token', 'WECHAT_INVALID_RESPONSE');
  }
  accessTokenCache = {
    value: data.access_token,
    expiresAt: Date.now() + Math.max(Number(data.expires_in || 7200) - CACHE_SAFETY_SECONDS, 60) * 1000,
  };
  return accessTokenCache.value;
}

async function getJsapiTicket(credentials) {
  if (ticketCache?.expiresAt > Date.now()) return ticketCache.value;
  const accessToken = await getAccessToken(credentials);
  const data = await requestWeChat(TICKET_URL, {
    access_token: accessToken,
    type: 'jsapi',
  });
  if (!data.ticket) {
    throw new WeChatShareError('微信未返回 jsapi_ticket', 'WECHAT_INVALID_RESPONSE');
  }
  ticketCache = {
    value: data.ticket,
    expiresAt: Date.now() + Math.max(Number(data.expires_in || 7200) - CACHE_SAFETY_SECONDS, 60) * 1000,
  };
  return ticketCache.value;
}

async function createSignature(url) {
  const credentials = await getCredentials();
  if (!credentials.enabled || !credentials.appId || !credentials.appSecret) {
    return { enabled: false };
  }

  const ticket = await getJsapiTicket(credentials);
  const nonceStr = crypto.randomBytes(16).toString('hex');
  const timestamp = Math.floor(Date.now() / 1000);
  const signature = crypto
    .createHash('sha1')
    .update(`jsapi_ticket=${ticket}&noncestr=${nonceStr}&timestamp=${timestamp}&url=${url}`)
    .digest('hex');

  return {
    enabled: true,
    appId: credentials.appId,
    timestamp,
    nonceStr,
    signature,
  };
}

module.exports = {
  createSignature,
  getCredentials,
  clearCache,
  WeChatShareError,
};
