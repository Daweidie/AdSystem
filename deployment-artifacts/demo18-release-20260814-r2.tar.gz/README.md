# 视频广告资源管理系统

本仓库包含两个独立项目：

- `backend`：Node.js + Express + MySQL API 服务
- `frontend`：Vue 3 + Vite H5 管理端骨架

## 快速开始

```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

数据库表结构位于 `backend/sql/schema.sql`。首次启动或拉取短链分发功能更新后执行：

```bash
cd backend
npm run migrate
```

迁移脚本可重复执行；`003_playback_events_indexes.sql` 为播放事件与域名选择补充组合索引。

## 验证

```bash
cd backend
npm test
```

```bash
cd frontend
npm run build
npm run test:e2e
```

## 管理后台与本地验收账号

本地启动后访问 `http://localhost:5173`，登录后进入产品素材资源管理后台。

| 角色 | 登录手机号 | 演示密码 | 权限范围 |
| --- | --- | --- | --- |
| 超级管理员 | `13800000001` | `Demo123!` | 全部后台功能、域名配置、系统管理员及系统初始化 |
| 系统管理员 | `13800000002` | `Demo123!` | 日常运营、业务组、素材组及推广员管理，无域名配置权限 |
| 业务组管理员 | `13800000003` | `Demo123!` | 管理本业务组素材、素材组；仅查看本组推广员 |
| 一般用户 | `13800000004` | `Demo123!` | 仅查看和使用本业务组素材及推广链接 |

验收账号由 `npm run migrate` 可重复初始化，登录页不会展示账号或预填密码。正式上线前必须修改或停用这些账号，
并将 `JWT_SECRET` 替换为高强度随机值。

主要后台功能包括：运营总览、素材列表、素材组、云端视频上传、推广链接、
微信卡片链接复制、推广员、业务组、到期提醒和系统管理员账号管理。播放页及
短链跳转保持免登录，便于客户从微信信息卡片直接观看视频。

客户域名尚未审核通过时，可先用服务器 IP 演示。域名可用后，由超级管理员
进入“系统设置 → 域名池管理”，添加一个或多个 `https://客户域名`。
启用域名会参与新推广链接的均衡分配：优先使用已分配链接数量最少的域名，同
数量时主域名优先。停用域名不再接收新链接，历史投放链接保持原地址。正式微信
投放应使用已备案并配置 HTTPS 证书的域名。

### 微信公众号分享卡片

超级管理员进入“系统设置 → 域名池管理 → 微信公众号分享卡片”后填写：

- 微信落地域名：完整的 HTTPS 根地址，例如 `https://video.example.com`，不能带路径、参数、账号信息或锚点；
- 公众号 AppID；
- 公众号 AppSecret（加密保存，配置接口仅返回已配置状态和脱敏值）；
- 以上三项齐全且微信平台设置完成后再打开启用开关，备案完成前可以留空并保持停用。

启用时系统会把微信落地域名加入启用的自建域名池，新生成的 Suolink 长链接会
指向该域名下的 `/play` 页面，不会改写历史短链接。还必须在微信公众平台把该
域名加入“JS接口安全域名”，把服务器出口 IP 加入公众号 IP 白名单，并为已备案
域名部署有效的 HTTPS 证书。配置保存后可在同页运行“投放链路检测”。

微信自定义卡片发送时，先在微信内打开推广链接，再通过右上角“发送给朋友”分享，直接粘贴网址
不保证触发公众号 JS-SDK 自定义卡片。

Playwright 测试默认使用 Windows Edge，可通过 `PLAYWRIGHT_EDGE_PATH` 覆盖浏览器路径。

短链相关接口：

- `POST /api/shortlink/generate`：生成并保存短链
- `GET /api/shortlink/list`：列表、视频筛选和时间排序
- `GET /api/shortlink/:id/stats`：单条短链统计
- `POST /api/shortlink/toggle`：停用/启用
- `GET /api/statistics/shortlink`：管理端统计卡片
- `POST /api/video/:id/events`：上报 `start/progress/complete/error` 播放事件
- `DELETE /api/video/:id`：幂等删除腾讯云媒资并软删除本地视频
- `GET /api/video/access?fileId=...`：播放文档返回前的 404/410 门禁
- `POST /api/domain`、`PUT /api/domain/:id`、`DELETE /api/domain/:id`：域名管理
- `POST /api/domain/:id/toggle`：启用或停用域名

生产环境建议配置 `PLAY_PAGE_BASE_URL`（完整播放页地址）和
`TRUST_PROXY_HOPS`；缩链平台必须配置账号中已绑定生效的 `SUOLINK_DOMAIN`，
统计接口还需要配置 `SUOLINK_STATS_API_URL`。播放器签名密钥留空时，后端会调用
腾讯云 `DescribeDefaultDistributionConfig` 获取正确的播放密钥并仅在内存中缓存。

开发环境由 Vite 中间件在返回 `/play` 前调用访问门禁；生产环境必须使用
`nginx/demo18.conf.template` 中的精确 `/play` 代理，才能让过期/已删除视频的
顶层文档返回 HTTP 410。
