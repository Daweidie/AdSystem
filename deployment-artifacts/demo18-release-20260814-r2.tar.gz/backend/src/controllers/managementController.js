const pool = require('../config/db');
const {
  createToken,
  hashPassword,
  verifyPassword,
  TOKEN_TTL_SECONDS,
} = require('../services/authService');
const { getCustomerBaseUrl } = require('../services/runtimeConfigService');

const ROLES = ['super_admin', 'system_admin', 'business_manager', 'general_user'];
const USER_ROLES = ['business_manager', 'general_user'];

function httpError(status, message, code = 'VALIDATION_ERROR') {
  const error = new Error(message);
  error.status = status;
  error.code = code;
  return error;
}

function positiveId(value, field = 'id', optional = false) {
  if (optional && (value === null || value === undefined || value === '')) return null;
  if (!/^\d+$/.test(String(value)) || BigInt(value) <= 0n) {
    throw httpError(400, `${field} 必须是正整数`);
  }
  return String(value);
}

function text(value, field, maximum = 255, optional = false) {
  const normalized = typeof value === 'string' ? value.trim() : '';
  if (!normalized && !optional) throw httpError(400, `${field}不能为空`);
  if (normalized.length > maximum) throw httpError(400, `${field}不能超过 ${maximum} 个字符`);
  return normalized || null;
}

function publicUser(row) {
  return {
    id: row.id,
    name: row.name,
    phone: row.phone,
    role: row.role,
    businessGroupId: row.business_group_id,
    businessGroupName: row.business_group_name || null,
    status: row.status,
    expiresAt: row.expires_at,
    createdAt: row.created_at,
  };
}

async function login(req, res, next) {
  try {
    const phone = text(req.body?.phone, '登录手机号', 32);
    const password = text(req.body?.password, '登录密码', 128);
    const [rows] = await pool.execute(
      `SELECT u.*, bg.name AS business_group_name
       FROM users u LEFT JOIN business_groups bg ON bg.id = u.business_group_id
       WHERE u.phone = ? LIMIT 1`,
      [phone],
    );
    const user = rows[0];

    if (!user || !verifyPassword(password, user.password_salt, user.password_hash)) {
      throw httpError(401, '手机号或密码不正确', 'LOGIN_FAILED');
    }
    if (user.status !== 'active') throw httpError(403, '账号已停用', 'ACCOUNT_DISABLED');
    if (user.expires_at && new Date(user.expires_at).getTime() <= Date.now()) {
      throw httpError(403, '账号已到期', 'ACCOUNT_EXPIRED');
    }

    res.json({
      success: true,
      data: {
        token: createToken(user),
        expiresIn: TOKEN_TTL_SECONDS,
        user: publicUser(user),
      },
      message: '登录成功',
    });
  } catch (error) {
    next(error);
  }
}

function me(req, res) {
  res.json({ success: true, data: publicUser(req.auth) });
}

function scopeSql(user, alias = 'v') {
  if (['super_admin', 'system_admin'].includes(user.role)) return { sql: '', params: [] };
  return { sql: ` AND ${alias}.business_group_id = ?`, params: [user.business_group_id || 0] };
}

async function requireScopedRecord(user, table, id, groupColumn = 'business_group_id') {
  const platformAdmin = ['super_admin', 'system_admin'].includes(user.role);
  const [rows] = await pool.execute(
    `SELECT id, ${groupColumn} FROM ${table} WHERE id = ?${platformAdmin ? '' : ` AND ${groupColumn} = ?`} LIMIT 1`,
    platformAdmin ? [id] : [id, user.business_group_id || 0],
  );
  if (!rows[0]) throw httpError(403, '只能管理本业务组的数据', 'PERMISSION_DENIED');
  return rows[0];
}

async function dashboard(req, res, next) {
  try {
    const platformAdmin = ['super_admin', 'system_admin'].includes(req.auth.role);
    const scope = scopeSql(req.auth);
    const videoWhere = `WHERE v.status <> 'deleted'${scope.sql}`;
    const [materialRows] = await pool.execute(
      `SELECT COUNT(*) AS total,
              SUM(v.status = 'ready' AND v.expires_at > NOW()) AS effective,
              SUM(v.created_at >= CURRENT_DATE) AS today_uploads,
              SUM(v.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) AS week_uploads,
              SUM(v.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) AS month_uploads,
              SUM(v.expires_at <= DATE_ADD(NOW(), INTERVAL 15 DAY) AND v.expires_at > NOW()) AS expiring
       FROM videos v ${videoWhere}`,
      scope.params,
    );
    const [linkRows] = await pool.execute(
      `SELECT COUNT(*) AS total_links, COALESCE(SUM(sl.clicks), 0) AS visits
       FROM short_links sl INNER JOIN videos v ON v.id = sl.video_id
       WHERE 1=1${scope.sql}`,
      scope.params,
    );
    const [playRows] = await pool.execute(
      `SELECT SUM(pl.event_type = 'start') AS starts,
              SUM(pl.event_type = 'complete') AS completes,
              SUM(pl.event_type = 'start' AND pl.played_at >= CURRENT_DATE) AS today_starts,
              SUM(pl.event_type = 'complete' AND pl.played_at >= CURRENT_DATE) AS today_completes
       FROM play_logs pl INNER JOIN videos v ON v.id = pl.video_id
       WHERE 1=1${scope.sql}`,
      scope.params,
    );
    const [peopleRows] = await pool.execute(
      `SELECT COUNT(*) AS promoters,
              SUM(u.status = 'active' AND (u.expires_at IS NULL OR u.expires_at > NOW())) AS effective_promoters
       FROM users u WHERE u.role = 'general_user'${
         platformAdmin ? '' : ' AND u.business_group_id = ?'
       }`,
      platformAdmin ? [] : [req.auth.business_group_id || 0],
    );
    let groupRow = null;
    if (platformAdmin) {
      [[groupRow]] = await pool.execute(
        `SELECT COUNT(*) AS business_groups,
                SUM(status = 'active' AND (expires_at IS NULL OR expires_at > NOW())) AS effective_groups
         FROM business_groups`,
      );
    }
    const materials = materialRows[0] || {};
    const links = linkRows[0] || {};
    const plays = playRows[0] || {};
    const people = peopleRows[0] || {};
    const completionRate = Number(plays.starts) > 0
      ? Math.round((Number(plays.completes || 0) / Number(plays.starts)) * 100)
      : 0;

    res.json({
      success: true,
      data: {
        materials: {
          total: Number(materials.total || 0), effective: Number(materials.effective || 0),
          todayUploads: Number(materials.today_uploads || 0), weekUploads: Number(materials.week_uploads || 0),
          monthUploads: Number(materials.month_uploads || 0), expiring: Number(materials.expiring || 0),
        },
        people: {
          ...(platformAdmin ? {
            businessGroups: Number(groupRow?.business_groups || 0),
            effectiveGroups: Number(groupRow?.effective_groups || 0),
          } : {}),
          promoters: Number(people.promoters || 0), effectivePromoters: Number(people.effective_promoters || 0),
        },
        delivery: {
          totalLinks: Number(links.total_links || 0), visits: Number(links.visits || 0),
          starts: Number(plays.starts || 0), completes: Number(plays.completes || 0), completionRate,
          todayStarts: Number(plays.today_starts || 0), todayCompletes: Number(plays.today_completes || 0),
        },
      },
    });
  } catch (error) { next(error); }
}

async function listBusinessGroups(req, res, next) {
  try {
    const params = [];
    let where = '';
    if (!['super_admin', 'system_admin'].includes(req.auth.role)) {
      where = 'WHERE bg.id = ?';
      params.push(req.auth.business_group_id || 0);
    }
    const [rows] = await pool.execute(
      `SELECT bg.*, u.name AS manager_name, u.phone AS manager_phone,
              (SELECT COUNT(*) FROM users m WHERE m.business_group_id = bg.id AND m.role IN ('business_manager','general_user')) AS member_count
       FROM business_groups bg
       LEFT JOIN users u ON u.id = bg.manager_user_id
       ${where} ORDER BY bg.created_at DESC`, params,
    );
    res.json({ success: true, data: rows });
  } catch (error) { next(error); }
}

async function saveBusinessGroup(req, res, next) {
  try {
    const name = text(req.body?.name, '业务组名称', 128);
    const expiresAt = req.body?.expiresAt || null;
    const managerName = text(req.body?.managerName, '管理员用户名', 128);
    const managerPhone = text(req.body?.managerPhone, '管理员登录手机', 32);
    const password = text(req.body?.password, '管理员密码', 128);
    const credentials = hashPassword(password);
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      const [groupResult] = await connection.execute(
        `INSERT INTO business_groups (name, status, expires_at) VALUES (?, 'active', ?)`,
        [name, expiresAt],
      );
      const [userResult] = await connection.execute(
        `INSERT INTO users
           (name, phone, password_salt, password_hash, role, business_group_id, status, expires_at)
         VALUES (?, ?, ?, ?, 'business_manager', ?, 'active', ?)`,
        [managerName, managerPhone, credentials.salt, credentials.hash, groupResult.insertId, expiresAt],
      );
      await connection.execute('UPDATE business_groups SET manager_user_id = ? WHERE id = ?', [userResult.insertId, groupResult.insertId]);
      await connection.commit();
      res.status(201).json({ success: true, data: { id: groupResult.insertId }, message: '业务组添加成功' });
    } catch (error) {
      await connection.rollback();
      if (error.code === 'ER_DUP_ENTRY') throw httpError(409, '业务组名称或管理员手机号已存在', 'DUPLICATE_RECORD');
      throw error;
    } finally { connection.release(); }
  } catch (error) { next(error); }
}

async function updateBusinessGroup(req, res, next) {
  let connection;
  try {
    const id = positiveId(req.params.id, '业务组');
    connection = await pool.getConnection();
    await connection.beginTransaction();

    const [[group]] = await connection.execute(
      'SELECT id, manager_user_id FROM business_groups WHERE id = ? LIMIT 1 FOR UPDATE',
      [id],
    );
    if (!group) throw httpError(404, '业务组不存在', 'BUSINESS_GROUP_NOT_FOUND');

    const groupFields = [];
    const groupParams = [];
    const managerFields = [];
    const managerParams = [];
    if (req.body?.name !== undefined) {
      groupFields.push('name = ?');
      groupParams.push(text(req.body.name, '业务组名称', 128));
    }
    if (req.body?.status !== undefined) {
      if (!['active', 'disabled'].includes(req.body.status)) throw httpError(400, '业务组状态不正确');
      groupFields.push('status = ?');
      groupParams.push(req.body.status);
      managerFields.push('status = ?');
      managerParams.push(req.body.status);
    }
    if (req.body?.expiresAt !== undefined) {
      groupFields.push('expires_at = ?');
      groupParams.push(req.body.expiresAt || null);
    }

    if (req.body?.managerName !== undefined) {
      managerFields.push('name = ?');
      managerParams.push(text(req.body.managerName, '管理员用户名', 128));
    }
    if (req.body?.managerPhone !== undefined) {
      managerFields.push('phone = ?');
      managerParams.push(text(req.body.managerPhone, '管理员登录手机', 32));
    }
    if (req.body?.expiresAt !== undefined) {
      managerFields.push('expires_at = ?');
      managerParams.push(req.body.expiresAt || null);
    }
    if (req.body?.password) {
      const credentials = hashPassword(text(req.body.password, '管理员密码', 128));
      managerFields.push('password_salt = ?', 'password_hash = ?');
      managerParams.push(credentials.salt, credentials.hash);
    }

    if (!groupFields.length && !managerFields.length) throw httpError(400, '没有可更新的内容');
    if (managerFields.length && !group.manager_user_id) {
      throw httpError(409, '该业务组尚未指定管理员', 'BUSINESS_GROUP_MANAGER_MISSING');
    }

    if (groupFields.length) {
      await connection.execute(
        `UPDATE business_groups SET ${groupFields.join(', ')} WHERE id = ?`,
        [...groupParams, id],
      );
    }
    if (managerFields.length) {
      await connection.execute(
        `UPDATE users SET ${managerFields.join(', ')} WHERE id = ? AND role = 'business_manager'`,
        [...managerParams, group.manager_user_id],
      );
    }

    await connection.commit();
    res.json({ success: true, data: { id }, message: '业务组资料已更新' });
  } catch (error) {
    if (connection) await connection.rollback().catch(() => {});
    if (error.code === 'ER_DUP_ENTRY') {
      return next(httpError(409, '业务组名称或管理员手机号已存在', 'DUPLICATE_RECORD'));
    }
    next(error);
  } finally {
    connection?.release();
  }
}

async function listUsers(req, res, next) {
  try {
    const role = req.query.role;
    const params = [];
    const conditions = [];
    if (role && ROLES.includes(role)) { conditions.push('u.role = ?'); params.push(role); }
    if (req.auth.role === 'business_manager') {
      conditions.push('u.business_group_id = ?'); params.push(req.auth.business_group_id || 0);
      conditions.push("u.role = 'general_user'");
    } else if (req.auth.role === 'system_admin') {
      conditions.push("u.role IN ('business_manager','general_user')");
    } else if (req.auth.role !== 'super_admin') {
      conditions.push('u.business_group_id = ?'); params.push(req.auth.business_group_id || 0);
      conditions.push("u.role IN ('business_manager','general_user')");
    }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const [rows] = await pool.execute(
      `SELECT u.id, u.name, u.phone, u.role, u.business_group_id, u.status,
              u.expires_at, u.created_at, bg.name AS business_group_name
       FROM users u LEFT JOIN business_groups bg ON bg.id = u.business_group_id
       ${where} ORDER BY u.created_at DESC`, params,
    );
    res.json({ success: true, data: rows });
  } catch (error) { next(error); }
}

async function saveUser(req, res, next) {
  try {
    const name = text(req.body?.name, '用户名', 128);
    const phone = text(req.body?.phone, '登录账号', 32);
    const password = text(req.body?.password, '登录密码', 128);
    let role = req.body?.role || 'general_user';
    if (!ROLES.includes(role)) throw httpError(400, '账号角色不正确');
    if (req.auth.role === 'business_manager') role = 'general_user';
    if (req.auth.role !== 'super_admin' && !USER_ROLES.includes(role)) {
      throw httpError(403, '只有超级管理员可以创建系统管理员', 'PERMISSION_DENIED');
    }
    const businessGroupId = role === 'general_user' || role === 'business_manager'
      ? positiveId(req.auth.role === 'business_manager' ? req.auth.business_group_id : req.body?.businessGroupId, '业务组')
      : null;
    const credentials = hashPassword(password);
    const [result] = await pool.execute(
      `INSERT INTO users
         (name, phone, password_salt, password_hash, role, business_group_id, status, expires_at)
       VALUES (?, ?, ?, ?, ?, ?, 'active', ?)`,
      [name, phone, credentials.salt, credentials.hash, role, businessGroupId, req.body?.expiresAt || null],
    );
    res.status(201).json({ success: true, data: { id: result.insertId }, message: '账号添加成功' });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') return next(httpError(409, '登录手机号已存在', 'DUPLICATE_RECORD'));
    next(error);
  }
}

async function updateUser(req, res, next) {
  try {
    const id = positiveId(req.params.id);
    await requireScopedRecord(req.auth, 'users', id);
    const [[target]] = await pool.execute(
      'SELECT role, business_group_id FROM users WHERE id = ? LIMIT 1',
      [id],
    );
    if (!target) throw httpError(404, '账号不存在', 'USER_NOT_FOUND');
    if (target && ['super_admin', 'system_admin'].includes(target.role) && req.auth.role !== 'super_admin') {
      throw httpError(403, '只有超级管理员可以管理系统管理员', 'PERMISSION_DENIED');
    }
    if (req.auth.role === 'business_manager' && target?.role !== 'general_user') {
      throw httpError(403, '业务组管理员只能管理一般用户', 'PERMISSION_DENIED');
    }
    const fields = [];
    const params = [];
    if (req.body?.name !== undefined) { fields.push('name = ?'); params.push(text(req.body.name, '用户名', 128)); }
    if (req.body?.phone !== undefined) { fields.push('phone = ?'); params.push(text(req.body.phone, '登录手机号', 32)); }
    if (req.body?.businessGroupId !== undefined) {
      if (!USER_ROLES.includes(target.role)) {
        throw httpError(400, '平台管理员不能设置所属业务组');
      }
      if (target.role === 'business_manager') {
        throw httpError(400, '业务组管理员请通过业务组编辑调整归属');
      }
      if (req.auth.role === 'business_manager') {
        throw httpError(403, '业务组管理员不能调整账号所属业务组', 'PERMISSION_DENIED');
      }
      const businessGroupId = positiveId(req.body.businessGroupId, '业务组');
      const [[group]] = await pool.execute(
        'SELECT id FROM business_groups WHERE id = ? LIMIT 1',
        [businessGroupId],
      );
      if (!group) throw httpError(404, '业务组不存在', 'BUSINESS_GROUP_NOT_FOUND');
      fields.push('business_group_id = ?'); params.push(businessGroupId);
    }
    if (req.body?.status !== undefined) {
      if (!['active', 'disabled'].includes(req.body.status)) throw httpError(400, '账号状态不正确');
      fields.push('status = ?'); params.push(req.body.status);
    }
    if (req.body?.expiresAt !== undefined) { fields.push('expires_at = ?'); params.push(req.body.expiresAt || null); }
    if (req.body?.password) {
      const credentials = hashPassword(text(req.body.password, '登录密码', 128));
      fields.push('password_salt = ?', 'password_hash = ?'); params.push(credentials.salt, credentials.hash);
    }
    if (!fields.length) throw httpError(400, '没有可更新的内容');
    params.push(id);
    try {
      await pool.execute(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`, params);
    } catch (error) {
      if (error.code === 'ER_DUP_ENTRY') throw httpError(409, '登录手机号已存在', 'DUPLICATE_RECORD');
      throw error;
    }
    res.json({ success: true, data: { id }, message: '账号资料已更新' });
  } catch (error) { next(error); }
}

async function deleteUser(req, res, next) {
  try {
    const id = positiveId(req.params.id);
    await requireScopedRecord(req.auth, 'users', id);
    const [[target]] = await pool.execute('SELECT role FROM users WHERE id = ? LIMIT 1', [id]);
    if (target && ['super_admin', 'system_admin'].includes(target.role) && req.auth.role !== 'super_admin') {
      throw httpError(403, '只有超级管理员可以管理系统管理员', 'PERMISSION_DENIED');
    }
    if (req.auth.role === 'business_manager' && target?.role !== 'general_user') {
      throw httpError(403, '业务组管理员只能管理一般用户', 'PERMISSION_DENIED');
    }
    if (String(req.auth.id) === id) throw httpError(409, '不能删除当前登录账号', 'ACCOUNT_IN_USE');
    await pool.execute("UPDATE users SET status = 'disabled' WHERE id = ?", [id]);
    res.json({ success: true, data: { id }, message: '账号已停用' });
  } catch (error) { next(error); }
}

async function listMaterialGroups(req, res, next) {
  try {
    const params = [];
    let where = '';
    if (!['super_admin', 'system_admin'].includes(req.auth.role)) {
      where = 'WHERE mg.business_group_id = ?'; params.push(req.auth.business_group_id || 0);
    } else if (req.query.businessGroupId) {
      where = 'WHERE mg.business_group_id = ?'; params.push(positiveId(req.query.businessGroupId, '业务组'));
    }
    const [rows] = await pool.execute(
      `SELECT mg.*, bg.name AS business_group_name,
              (SELECT COUNT(*) FROM videos v WHERE v.material_group_id = mg.id AND v.status <> 'deleted') AS material_count
       FROM material_groups mg LEFT JOIN business_groups bg ON bg.id = mg.business_group_id
       ${where} ORDER BY mg.created_at DESC`, params,
    );
    res.json({ success: true, data: rows });
  } catch (error) { next(error); }
}

async function saveMaterialGroup(req, res, next) {
  try {
    const businessGroupId = positiveId(
      ['super_admin', 'system_admin'].includes(req.auth.role) ? req.body?.businessGroupId : req.auth.business_group_id,
      '业务组',
    );
    const name = text(req.body?.name, '素材组名称', 128);
    const [result] = await pool.execute(
      `INSERT INTO material_groups (business_group_id, name, is_enabled) VALUES (?, ?, 1)`,
      [businessGroupId, name],
    );
    res.status(201).json({ success: true, data: { id: result.insertId }, message: '素材组添加成功' });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') return next(httpError(409, '该业务组下已存在同名素材组', 'DUPLICATE_RECORD'));
    next(error);
  }
}

async function updateMaterialGroup(req, res, next) {
  try {
    const id = positiveId(req.params.id);
    await requireScopedRecord(req.auth, 'material_groups', id);
    const fields = [];
    const params = [];
    if (req.body?.name !== undefined) { fields.push('name = ?'); params.push(text(req.body.name, '素材组名称', 128)); }
    if (req.body?.isEnabled !== undefined) { fields.push('is_enabled = ?'); params.push(req.body.isEnabled ? 1 : 0); }
    if (!fields.length) throw httpError(400, '没有可更新的内容');
    params.push(id);
    await pool.execute(`UPDATE material_groups SET ${fields.join(', ')} WHERE id = ?`, params);
    res.json({ success: true, data: { id }, message: '素材组已更新' });
  } catch (error) { next(error); }
}

async function deleteMaterialGroup(req, res, next) {
  try {
    const id = positiveId(req.params.id);
    await requireScopedRecord(req.auth, 'material_groups', id);
    const [[usage]] = await pool.execute("SELECT COUNT(*) AS total FROM videos WHERE material_group_id = ? AND status <> 'deleted'", [id]);
    if (Number(usage.total) > 0) throw httpError(409, '素材组内仍有素材，不能删除', 'GROUP_IN_USE');
    await pool.execute('DELETE FROM material_groups WHERE id = ?', [id]);
    res.json({ success: true, data: { id }, message: '素材组已删除' });
  } catch (error) { next(error); }
}

async function listMaterials(req, res, next) {
  try {
    const scope = scopeSql(req.auth);
    const params = [...scope.params];
    let filters = scope.sql;
    if (req.query.businessGroupId && ['super_admin', 'system_admin'].includes(req.auth.role)) {
      filters += ' AND v.business_group_id = ?'; params.push(positiveId(req.query.businessGroupId, '业务组'));
    }
    if (req.query.materialGroupId) { filters += ' AND v.material_group_id = ?'; params.push(positiveId(req.query.materialGroupId, '素材组')); }
    if (req.query.keyword) { filters += ' AND (v.title LIKE ? OR v.description LIKE ?)'; const keyword = `%${String(req.query.keyword).slice(0, 100)}%`; params.push(keyword, keyword); }
    const [rows] = await pool.execute(
      `SELECT v.id, v.file_id, v.title, v.description, v.cover_url, v.video_url, v.duration,
              v.status, v.expires_at, v.created_at, v.business_group_id, v.material_group_id,
              bg.name AS business_group_name, mg.name AS material_group_name,
              SUM(pl.event_type = 'start') AS play_count,
              SUM(pl.event_type = 'complete') AS complete_count
       FROM videos v
       LEFT JOIN business_groups bg ON bg.id = v.business_group_id
       LEFT JOIN material_groups mg ON mg.id = v.material_group_id
       LEFT JOIN play_logs pl ON pl.video_id = v.id
       WHERE v.status <> 'deleted'${filters}
       GROUP BY v.id ORDER BY v.created_at DESC`, params,
    );
    if (!rows.length) return res.json({ success: true, data: [] });
    const ids = rows.map((row) => row.id);
    const [links] = await pool.query(
      `SELECT sl.id, sl.video_id, sl.short_url, sl.status, sl.clicks, sl.created_at,
              COALESCE(d.platform,
                CASE WHEN d.type = 'suolink' THEN 'suolink' ELSE 'self' END
              ) AS platform
       FROM short_links sl
       INNER JOIN domains d ON d.id = sl.domain_id
       WHERE sl.video_id IN (?) ORDER BY sl.created_at DESC`, [ids],
    );
    const byVideo = new Map();
    for (const link of links) {
      const key = String(link.video_id);
      if (!byVideo.has(key)) byVideo.set(key, []);
      byVideo.get(key).push(link);
    }
    res.json({
      success: true,
      data: rows.map((row) => ({
        ...row,
        play_count: Number(row.play_count || 0),
        complete_count: Number(row.complete_count || 0),
        completion_rate: Number(row.play_count) ? Math.round((Number(row.complete_count) / Number(row.play_count)) * 100) : 0,
        short_links: byVideo.get(String(row.id)) || [],
      })),
    });
  } catch (error) { next(error); }
}

async function updateMaterial(req, res, next) {
  try {
    const id = positiveId(req.params.id);
    const current = await requireScopedRecord(req.auth, 'videos', id);
    const platformAdmin = ['super_admin', 'system_admin'].includes(req.auth.role);
    if (req.body?.businessGroupId !== undefined && !platformAdmin) {
      throw httpError(403, '只有平台管理员可以调整素材所属业务组', 'PERMISSION_DENIED');
    }
    const fields = [];
    const params = [];
    if (req.body?.title !== undefined) { fields.push('title = ?'); params.push(text(req.body.title, '素材名称', 255)); }
    if (req.body?.description !== undefined) { fields.push('description = ?'); params.push(text(req.body.description, '素材简介', 2000, true)); }
    const businessGroupId = req.body?.businessGroupId !== undefined
      ? positiveId(req.body.businessGroupId, '业务组', true)
      : current.business_group_id;
    const materialGroupId = req.body?.materialGroupId !== undefined
      ? positiveId(req.body.materialGroupId, '素材组', true)
      : current.material_group_id;
    if (materialGroupId) {
      const [groups] = await pool.execute(
        'SELECT id FROM material_groups WHERE id = ? AND business_group_id = ? LIMIT 1',
        [materialGroupId, businessGroupId || 0],
      );
      if (!groups.length) throw httpError(400, '所选素材组不属于当前业务组');
    }
    if (req.body?.businessGroupId !== undefined) { fields.push('business_group_id = ?'); params.push(businessGroupId); }
    if (req.body?.materialGroupId !== undefined) { fields.push('material_group_id = ?'); params.push(materialGroupId); }
    if (req.body?.status !== undefined) {
      if (!['ready', 'disabled'].includes(req.body.status)) throw httpError(400, '素材状态不正确');
      fields.push('status = ?'); params.push(req.body.status);
    }
    if (!fields.length) throw httpError(400, '没有可更新的内容');
    params.push(id);
    await pool.execute(`UPDATE videos SET ${fields.join(', ')} WHERE id = ?`, params);
    res.json({ success: true, data: { id }, message: '素材已更新' });
  } catch (error) { next(error); }
}

async function expiringUsers(req, res, next) {
  try {
    const params = [];
    let scope = '';
    if (!['super_admin', 'system_admin'].includes(req.auth.role)) { scope = ' AND u.business_group_id = ?'; params.push(req.auth.business_group_id || 0); }
    const [rows] = await pool.execute(
      `SELECT u.id, u.name, u.phone, u.role, u.status, u.created_at, u.expires_at,
              bg.name AS business_group_name, DATEDIFF(u.expires_at, NOW()) AS remaining_days
       FROM users u LEFT JOIN business_groups bg ON bg.id = u.business_group_id
       WHERE u.role IN ('business_manager','general_user')
         AND u.expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 15 DAY)${scope}
       ORDER BY u.expires_at ASC`, params,
    );
    res.json({ success: true, data: rows });
  } catch (error) { next(error); }
}

function normalizeCustomerBaseUrl(value) {
  const raw = text(value, '客户链接', 255);
  let url;

  try { url = new URL(raw); }
  catch { throw httpError(400, '客户链接必须是完整的 http/https 地址'); }

  if (!['http:', 'https:'].includes(url.protocol)) {
    throw httpError(400, '客户链接仅支持 http 或 https');
  }
  if (url.username || url.password || url.search || url.hash) {
    throw httpError(400, '客户链接不能包含账号、参数或锚点');
  }
  if (url.pathname && url.pathname !== '/') {
    throw httpError(400, '请填写域名根地址，例如 https://video.example.com');
  }

  return `${url.protocol}//${url.host}`;
}

async function getCustomerLink(req, res, next) {
  void req;
  try {
    const configuredUrl = await getCustomerBaseUrl();
    const [[stored]] = await pool.execute(
      `SELECT config_value FROM system_configs
       WHERE config_key = 'customer_base_url' LIMIT 1`,
    );
    res.json({
      success: true,
      data: {
        url: configuredUrl,
        isCustom: Boolean(stored?.config_value),
        playExample: configuredUrl ? `${configuredUrl}/play?fileId=腾讯云FileId` : null,
        shortLinkExample: configuredUrl ? `${configuredUrl}/Ab12Cd` : null,
      },
    });
  } catch (error) { next(error); }
}

async function saveCustomerLink(req, res, next) {
  let connection;
  try {
    const baseUrl = normalizeCustomerBaseUrl(req.body?.url);
    connection = await pool.getConnection();
    await connection.beginTransaction();

    await connection.execute(
      `INSERT INTO system_configs (config_key, config_value)
       VALUES ('customer_base_url', ?)
       ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)`,
      [baseUrl],
    );

    const [sameDomainRows] = await connection.execute(
      `SELECT id FROM domains
       WHERE domain = ? AND platform = 'self' LIMIT 1 FOR UPDATE`,
      [baseUrl],
    );
    let domainId = sameDomainRows[0]?.id;

    if (!domainId) {
      const [result] = await connection.execute(
        `INSERT INTO domains
           (domain, type, platform, is_primary, is_enabled, remark)
         VALUES (?, 'self_hosted', 'self', 0, 1, '通过兼容接口加入的客户域名')`,
        [baseUrl],
      );
      domainId = result.insertId;
    }

    await connection.execute('UPDATE domains SET is_enabled = 1 WHERE id = ?', [domainId]);
    const [[primary]] = await connection.execute(
      `SELECT id FROM domains WHERE is_primary = 1 LIMIT 1 FOR UPDATE`,
    );
    if (!primary) {
      await connection.execute('UPDATE domains SET is_primary = (id = ?)', [domainId]);
      await connection.execute(
        `INSERT INTO system_configs (config_key, config_value)
         VALUES ('primary_domain_id', ?), ('shortlink_platform', 'self')
         ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)`,
        [domainId],
      );
    }
    await connection.commit();

    res.json({
      success: true,
      data: {
        url: baseUrl,
        domainId,
        playExample: `${baseUrl}/play?fileId=腾讯云FileId`,
        shortLinkExample: `${baseUrl}/Ab12Cd`,
      },
      message: '客户域名已加入域名池',
    });
  } catch (error) {
    if (connection) await connection.rollback().catch(() => {});
    if (error.code === 'ER_DUP_ENTRY') {
      return next(httpError(409, '该客户链接已存在，请在域名管理中确认状态', 'DUPLICATE_RECORD'));
    }
    next(error);
  } finally { connection?.release(); }
}

module.exports = {
  login, me, dashboard, listBusinessGroups, saveBusinessGroup, updateBusinessGroup,
  listUsers, saveUser, updateUser, deleteUser,
  listMaterialGroups, saveMaterialGroup, updateMaterialGroup, deleteMaterialGroup,
  listMaterials, updateMaterial, expiringUsers,
  getCustomerLink, saveCustomerLink,
};
