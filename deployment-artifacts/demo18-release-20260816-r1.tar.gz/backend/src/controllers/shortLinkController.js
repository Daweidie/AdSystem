const pool = require('../config/db');
const shortLinkService = require('../services/shortLinkService');
const suolinkService = require('../services/suolinkService');
const unifiedShortLinkService = require('../services/unifiedShortLinkService');
const logger = require('../utils/logger');
const {
  getEnabledWeChatLandingBaseUrl,
  getPlayPageBaseUrl,
} = require('../services/runtimeConfigService');

function createHttpError(status, message, code) {
  const error = new Error(message);
  error.status = status;
  error.code = code;
  return error;
}

function normalizeId(value, fieldName) {
  if (!/^\d+$/.test(String(value)) || BigInt(value) <= 0n) {
    throw createHttpError(400, `${fieldName} 必须是正整数`, 'VALIDATION_ERROR');
  }

  return String(value);
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function absoluteHttpUrl(value, req) {
  const raw = String(value || '').trim();
  if (!raw) return '';

  try {
    const url = new URL(raw, `${req.protocol}://${req.get('host')}`);
    return ['http:', 'https:'].includes(url.protocol) ? url.toString() : '';
  } catch {
    return '';
  }
}

function inlineJsonString(value) {
  return JSON.stringify(String(value || ''))
    .replaceAll('<', '\\u003c')
    .replaceAll('\u2028', '\\u2028')
    .replaceAll('\u2029', '\\u2029');
}

function renderShortLinkCardPage(target, req, redirectUrl) {
  const title = target.title || '视频播放';
  const description = target.description || '点击查看视频素材';
  // Nginx 会把公开的 /:code 重写到 /api/short/:code，必须使用数据库中保存的
  // 原始短链，避免微信卡片展示内部 API 路径。
  const shareUrl = absoluteHttpUrl(target.shortUrl || req.originalUrl, req);
  const coverUrl = absoluteHttpUrl(
    target.coverUrl || '/wechat-share-default.png',
    req,
  );
  const redirectTarget = redirectUrl.toString();

  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>${escapeHtml(title)}</title>
  <meta name="description" content="${escapeHtml(description)}" />
  <link rel="canonical" href="${escapeHtml(shareUrl)}" />
  <meta property="og:type" content="website" />
  <meta property="og:title" content="${escapeHtml(title)}" />
  <meta property="og:description" content="${escapeHtml(description)}" />
  <meta property="og:url" content="${escapeHtml(shareUrl)}" />
  <meta property="og:image" content="${escapeHtml(coverUrl)}" />
  <meta property="og:image:secure_url" content="${escapeHtml(coverUrl)}" />
  <meta property="og:image:width" content="600" />
  <meta property="og:image:height" content="600" />
  <meta itemprop="name" content="${escapeHtml(title)}" />
  <meta itemprop="description" content="${escapeHtml(description)}" />
  <meta itemprop="image" content="${escapeHtml(coverUrl)}" />
  <meta name="twitter:card" content="summary_large_image" />
  <noscript><meta http-equiv="refresh" content="0;url=${escapeHtml(redirectTarget)}" /></noscript>
  <style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#05070a;color:#e2e8f0;font-family:system-ui,sans-serif}.panel{text-align:center;padding:32px}h1{font-size:20px;margin:0 0 10px}p{color:#94a3b8;margin:0 0 18px}a{color:#5eead4}</style>
</head>
<body>
  <main class="panel"><h1>${escapeHtml(title)}</h1><p>正在打开视频…</p><a href="${escapeHtml(redirectTarget)}">未自动跳转时点此继续</a></main>
  <script>window.location.replace(${inlineJsonString(redirectTarget)});</script>
</body>
</html>`;
}

async function buildPlayUrl(req, fileId, baseUrl) {
  const configuredUrl =
    baseUrl || (await getPlayPageBaseUrl()) || req.get('origin');

  if (!configuredUrl) {
    throw createHttpError(
      500,
      '缺少 PLAY_PAGE_BASE_URL 或 FRONTEND_URL，无法生成播放页地址',
      'PLAY_URL_CONFIG_ERROR',
    );
  }

  const url = new URL(configuredUrl);

  if (!/\/play\/?$/.test(url.pathname)) {
    url.pathname = `${url.pathname.replace(/\/+$/, '')}/play`;
  }

  url.searchParams.set('fileId', fileId);
  return url.toString();
}

function extractProviderClicks(stats) {
  const candidates = [
    stats?.totalClicks,
    stats?.total_clicks,
    stats?.clicks,
    stats?.click,
    stats?.count,
    stats?.pv,
  ];

  for (const value of candidates) {
    const parsed = Number(value);

    if (Number.isFinite(parsed) && parsed >= 0) {
      return Math.floor(parsed);
    }
  }

  return null;
}

async function generateShortLink(req, res, next) {
  try {
    const requestedVideoId = req.body?.videoId ?? req.body?.video_id;
    const providedLongUrl =
      typeof req.body?.longUrl === 'string' ? req.body.longUrl.trim() : '';
    let videoRows;

    if (requestedVideoId !== undefined && requestedVideoId !== null) {
      const videoId = normalizeId(requestedVideoId, 'videoId');
      [videoRows] = await pool.execute(
        `SELECT id, file_id, business_group_id FROM videos WHERE id = ? LIMIT 1`,
        [videoId],
      );
    } else {
      let fileId;

      try {
        fileId = new URL(providedLongUrl).searchParams.get('fileId');
      } catch {
        fileId = null;
      }

      if (!fileId) {
        throw createHttpError(
          400,
          'videoId 不能为空，或 longUrl 中必须包含 fileId',
          'VALIDATION_ERROR',
        );
      }

      [videoRows] = await pool.execute(
        `SELECT id, file_id, business_group_id FROM videos WHERE file_id = ? LIMIT 1`,
        [fileId],
      );
    }

    if (videoRows.length === 0) {
      throw createHttpError(404, '视频不存在', 'VIDEO_NOT_FOUND');
    }

    if (
      !['super_admin', 'system_admin'].includes(req.auth?.role) &&
      String(videoRows[0].business_group_id || '') !== String(req.auth?.business_group_id || '')
    ) {
      throw createHttpError(403, '只能使用本业务组的素材', 'PERMISSION_DENIED');
    }

    const videoId = String(videoRows[0].id);
    const wechatLandingBaseUrl = await getEnabledWeChatLandingBaseUrl();
    const longUrl = wechatLandingBaseUrl
      ? await buildPlayUrl(req, videoRows[0].file_id, wechatLandingBaseUrl)
      : providedLongUrl || await buildPlayUrl(req, videoRows[0].file_id);
    const result = await unifiedShortLinkService.createShortLink(
      longUrl,
      req.body?.platform || 'auto',
      { videoId },
    );

    return res.status(201).json({
      success: true,
      data: result,
      message: result.fallbackFrom
        ? '缩链服务不可用，已降级为自建短链'
        : '短链接生成成功',
    });
  } catch (error) {
    return next(error);
  }
}

async function listShortLinks(req, res, next) {
  try {
    const parameters = [];
    let videoFilter = '';

    const requestedVideoId = req.query.videoId ?? req.query.video_id;

    if (requestedVideoId) {
      parameters.push(normalizeId(requestedVideoId, 'videoId'));
      videoFilter = 'WHERE sl.video_id = ?';
    }

    const sortDirection = String(req.query.sort || '').toLowerCase() === 'asc'
      ? 'ASC'
      : 'DESC';

    await pool.execute(
      `UPDATE short_links sl
       INNER JOIN videos v ON v.id = sl.video_id
       SET sl.status = 'expired'
       WHERE sl.status <> 'expired'
         AND ((sl.expires_at IS NOT NULL AND sl.expires_at <= NOW())
              OR v.expires_at <= NOW()
              OR v.status IN ('expired', 'deleted'))`,
    );

    const [rows] = await pool.execute(
      `SELECT sl.id, sl.video_id, v.title AS video_title, v.file_id,
              sl.short_code, sl.long_url, sl.short_url,
              COALESCE(d.platform,
                CASE WHEN d.type = 'suolink' THEN 'suolink' ELSE 'self' END
              ) AS platform,
              d.domain, sl.clicks, sl.status, sl.expires_at,
              sl.created_at, sl.updated_at
       FROM short_links sl
       INNER JOIN videos v ON v.id = sl.video_id
       INNER JOIN domains d ON d.id = sl.domain_id
       ${videoFilter}
       ORDER BY sl.created_at ${sortDirection}, sl.id ${sortDirection}`,
      parameters,
    );

    return res.json({
      success: true,
      data: rows.map((row) => ({
        ...row,
        clicks: Number(row.clicks || 0),
      })),
    });
  } catch (error) {
    return next(error);
  }
}

async function getShortLinkStats(req, res, next) {
  try {
    const shortLinkId = normalizeId(req.params.id, 'shortLinkId');
    const [rows] = await pool.execute(
      `SELECT sl.id, sl.short_url, sl.short_code, sl.provider_link_id, sl.clicks,
              COALESCE(d.platform,
                CASE WHEN d.type = 'suolink' THEN 'suolink' ELSE 'self' END
              ) AS platform,
              SUM(CASE WHEN pl.device_type = 'mobile' THEN 1 ELSE 0 END) AS mobile_clicks,
              SUM(CASE WHEN pl.device_type = 'pc' THEN 1 ELSE 0 END) AS pc_clicks
       FROM short_links sl
       INNER JOIN domains d ON d.id = sl.domain_id
       LEFT JOIN play_logs pl
         ON pl.short_link_id = sl.id AND pl.event_type = 'redirect'
       WHERE sl.id = ?
       GROUP BY sl.id, sl.short_url, sl.short_code, sl.provider_link_id,
                sl.clicks, d.platform, d.type
       LIMIT 1`,
      [shortLinkId],
    );

    if (rows.length === 0) {
      throw createHttpError(404, '短链接不存在', 'SHORT_LINK_NOT_FOUND');
    }

    let totalClicks = Number(rows[0].clicks || 0);

    if (rows[0].platform === 'suolink' && process.env.SUOLINK_STATS_API_URL) {
      try {
        const providerStats = await suolinkService.getLinkStats(
          rows[0].provider_link_id || rows[0].short_code,
        );
        const providerClicks = extractProviderClicks(providerStats);

        if (providerClicks !== null) {
          totalClicks = Math.max(totalClicks, providerClicks);
          await pool.execute(
            `UPDATE short_links SET clicks = GREATEST(clicks, ?) WHERE id = ?`,
            [totalClicks, shortLinkId],
          );
        }
      } catch (error) {
        // 第三方统计不可用时仍返回数据库中的最近一次点击量。
        logger.warn('suolink_statistics_cache_fallback', {
          code: error.code || 'SUOLINK_STATS_FAILED',
          shortLinkId,
          targetPlatform: 'suolink',
          cacheValue: totalClicks,
        });
      }
    }

    return res.json({
      success: true,
      data: {
        id: rows[0].id,
        shortUrl: rows[0].short_url,
        totalClicks,
        mobileClicks: Number(rows[0].mobile_clicks || 0),
        pcClicks: Number(rows[0].pc_clicks || 0),
      },
    });
  } catch (error) {
    return next(error);
  }
}

async function toggleShortLink(req, res, next) {
  let connection;
  let transactionFinished = false;

  try {
    const shortLinkId = normalizeId(
      req.body?.shortLinkId ?? req.body?.id,
      'shortLinkId',
    );
    connection = await pool.getConnection();
    await connection.beginTransaction();

    const [rows] = await connection.execute(
      `SELECT sl.id, sl.status, sl.expires_at, v.status AS video_status,
              v.expires_at AS video_expires_at
       FROM short_links sl
       INNER JOIN videos v ON v.id = sl.video_id
       WHERE sl.id = ?
       LIMIT 1
       FOR UPDATE`,
      [shortLinkId],
    );

    if (rows.length === 0) {
      throw createHttpError(404, '短链接不存在', 'SHORT_LINK_NOT_FOUND');
    }

    const row = rows[0];
    const expired =
      (row.expires_at && new Date(row.expires_at).getTime() <= Date.now()) ||
      (row.video_expires_at &&
        new Date(row.video_expires_at).getTime() <= Date.now()) ||
      ['expired', 'deleted'].includes(row.video_status);

    if (expired) {
      await connection.execute(
        `UPDATE short_links SET status = 'expired' WHERE id = ?`,
        [shortLinkId],
      );
      await connection.commit();
      transactionFinished = true;
      throw createHttpError(409, '已过期的短链接不能重新启用', 'SHORT_LINK_EXPIRED');
    }

    const shouldEnable =
      typeof req.body?.enabled === 'boolean'
        ? req.body.enabled
        : row.status !== 'active';
    const status = shouldEnable ? 'active' : 'disabled';

    await connection.execute(
      `UPDATE short_links SET status = ? WHERE id = ?`,
      [status, shortLinkId],
    );
    await connection.commit();
    transactionFinished = true;

    return res.json({
      success: true,
      data: { id: row.id, status },
      message: status === 'active' ? '短链接已启用' : '短链接已停用',
    });
  } catch (error) {
    if (connection && !transactionFinished) {
      await connection.rollback();
    }
    return next(error);
  } finally {
    connection?.release();
  }
}

async function redirectByCode(req, res, next) {
  try {
    const target = await shortLinkService.redirect(req.params.code, {
      referer: req.get('referer'),
      userAgent: req.get('user-agent'),
      ipAddress: req.ip,
    });

    if (!target?.url) {
      return res.status(404).json({
        success: false,
        data: null,
        code: 'SHORT_LINK_NOT_FOUND',
        message: '短链接不存在',
      });
    }

    const redirectUrl = new URL(target.url);
    redirectUrl.searchParams.set('shortLinkId', String(target.shortLinkId));
    const html = renderShortLinkCardPage(target, req, redirectUrl);
    return res
      .status(200)
      .set('Cache-Control', 'private, no-cache')
      .type('html')
      .send(html);
  } catch (error) {
    return next(error);
  }
}

module.exports = {
  generateShortLink,
  listShortLinks,
  getShortLinkStats,
  toggleShortLink,
  redirectByCode,
  renderShortLinkCardPage,
};
