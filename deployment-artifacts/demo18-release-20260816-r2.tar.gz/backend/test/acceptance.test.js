const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('crypto');
const path = require('path');

require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = require('../src/config/db');
const vodService = require('../src/services/vodService');
const suolinkService = require('../src/services/suolinkService');
const unifiedShortLinkService = require('../src/services/unifiedShortLinkService');
const shortLinkService = require('../src/services/shortLinkService');
const wechatShareService = require('../src/services/wechatShareService');
const { removeCardCover } = require('../src/services/cardCoverService');
const { decryptSecret } = require('../src/services/secretConfigService');
const app = require('../src/app');

const runId = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
let server;
let baseUrl;
let videoId;
let selfDomainId;
let originalPrimaryId;
let authToken;
const cleanupDomainIds = new Set();
const cleanupVideoIds = new Set();
const cleanupUserIds = new Set();
const cleanupBusinessGroupIds = new Set();

async function request(url, options = {}) {
  const isFormData = options.body instanceof FormData;
  const response = await fetch(`${baseUrl}${url}`, {
    ...options,
    headers: {
      Accept: 'application/json',
      ...(!isFormData ? { 'Content-Type': 'application/json' } : {}),
      ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
      ...options.headers,
    },
  });
  const payload = await response.json();
  return { response, payload };
}

test.before(async () => {
  const [primaryRows] = await pool.execute(
    'SELECT id FROM domains WHERE is_primary = 1 ORDER BY id LIMIT 1',
  );
  originalPrimaryId = primaryRows[0]?.id;

  const [domainResult] = await pool.execute(
    `INSERT INTO domains
       (domain, type, platform, is_primary, is_enabled, remark)
     VALUES (?, 'self_hosted', 'self', 0, 1, 'automated acceptance fixture')`,
    [`http://127.0.0.1:3001/api/short/test-${runId}`],
  );
  selfDomainId = domainResult.insertId;
  cleanupDomainIds.add(String(selfDomainId));

  const [videoResult] = await pool.execute(
    `INSERT INTO videos
       (file_id, title, status, expires_at)
     VALUES (?, ?, 'ready', DATE_ADD(NOW(), INTERVAL 1 DAY))`,
    [`test-${runId}`, `自动化验收 ${runId}`],
  );
  videoId = videoResult.insertId;
  cleanupVideoIds.add(String(videoId));

  server = app.listen(0, '127.0.0.1');
  await new Promise((resolve, reject) => {
    server.once('listening', resolve);
    server.once('error', reject);
  });
  baseUrl = `http://127.0.0.1:${server.address().port}`;
  const login = await request('/api/management/auth/login', {
    method: 'POST',
    body: JSON.stringify({ phone: '13800000001', password: 'Demo123!' }),
  });
  authToken = login.payload.data?.token;
  assert.ok(authToken, 'demo super admin login failed');
});

test.after(async () => {
  try {
    if (originalPrimaryId) {
      await pool.execute('UPDATE domains SET is_primary = (id = ?)', [originalPrimaryId]);
      await pool.execute(
        `INSERT INTO system_configs (config_key, config_value)
         VALUES ('primary_domain_id', ?)
         ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)`,
        [originalPrimaryId],
      );
    }

    if (cleanupVideoIds.size) {
      const videoIds = [...cleanupVideoIds];
      const placeholders = videoIds.map(() => '?').join(',');
      await pool.execute(`DELETE FROM play_logs WHERE video_id IN (${placeholders})`, videoIds);
      await pool.execute(`DELETE FROM short_links WHERE video_id IN (${placeholders})`, videoIds);
      await pool.execute(`DELETE FROM videos WHERE id IN (${placeholders})`, videoIds);
    }

    if (cleanupDomainIds.size) {
      const domainIds = [...cleanupDomainIds];
      const placeholders = domainIds.map(() => '?').join(',');
      await pool.execute(`DELETE FROM domains WHERE id IN (${placeholders})`, domainIds);
    }

    if (cleanupUserIds.size) {
      const userIds = [...cleanupUserIds];
      const placeholders = userIds.map(() => '?').join(',');
      await pool.execute(`DELETE FROM users WHERE id IN (${placeholders})`, userIds);
    }

    if (cleanupBusinessGroupIds.size) {
      const groupIds = [...cleanupBusinessGroupIds];
      const placeholders = groupIds.map(() => '?').join(',');
      await pool.execute(`DELETE FROM business_groups WHERE id IN (${placeholders})`, groupIds);
    }
  } finally {
    await new Promise((resolve) => server.close(resolve));
    await pool.end();
  }
});

test('all JSON APIs use the unified response envelope', async () => {
  const { response, payload } = await request('/health');
  assert.equal(response.status, 200);
  assert.deepEqual(Object.keys(payload).sort(), ['code', 'data', 'message', 'success']);
  assert.equal(payload.success, true);
});

test('management authentication and role permissions are enforced', async () => {
  const generalLogin = await request('/api/management/auth/login', {
    method: 'POST',
    body: JSON.stringify({ phone: '13800000004', password: 'Demo123!' }),
  });
  assert.equal(generalLogin.response.status, 200);
  assert.equal(generalLogin.payload.data.user.role, 'general_user');

  const generalToken = generalLogin.payload.data.token;
  const dashboard = await request('/api/management/dashboard', {
    headers: { Authorization: `Bearer ${generalToken}` },
  });
  assert.equal(dashboard.response.status, 200);
  assert.equal(Object.hasOwn(dashboard.payload.data.people, 'businessGroups'), false);
  assert.equal(Object.hasOwn(dashboard.payload.data.people, 'effectiveGroups'), false);

  const denied = await request(`/api/management/materials/${videoId}`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${generalToken}` },
    body: JSON.stringify({ status: 'disabled' }),
  });
  assert.equal(denied.response.status, 403);
  assert.equal(denied.payload.code, 'PERMISSION_DENIED');

  const publicPlayback = await request(`/api/video/access?fileId=test-${runId}`);
  assert.equal(publicPlayback.response.status, 200);

  const customerLink = await request('/api/management/customer-link');
  assert.equal(customerLink.response.status, 200);
  assert.ok(customerLink.payload.data.url);

  const deniedCustomerLink = await request('/api/management/customer-link', {
    headers: { Authorization: `Bearer ${generalToken}` },
  });
  assert.equal(deniedCustomerLink.response.status, 403);

  const invalidCustomerLink = await request('/api/management/customer-link', {
    method: 'PUT',
    body: JSON.stringify({ url: 'https://customer.example.com/play?fileId=1' }),
  });
  assert.equal(invalidCustomerLink.response.status, 400);
});

test('business managers have group-scoped read-only promoter access', async () => {
  const managerLogin = await request('/api/management/auth/login', {
    method: 'POST',
    body: JSON.stringify({ phone: '13800000003', password: 'Demo123!' }),
  });
  assert.equal(managerLogin.response.status, 200);
  assert.equal(managerLogin.payload.data.user.role, 'business_manager');
  const managerToken = managerLogin.payload.data.token;
  const managerGroupId = String(managerLogin.payload.data.user.businessGroupId);

  const dashboard = await request('/api/management/dashboard', {
    headers: { Authorization: `Bearer ${managerToken}` },
  });
  assert.equal(dashboard.response.status, 200);
  assert.equal(Object.hasOwn(dashboard.payload.data.people, 'businessGroups'), false);
  assert.equal(Object.hasOwn(dashboard.payload.data.people, 'effectiveGroups'), false);

  const users = await request('/api/management/users', {
    headers: { Authorization: `Bearer ${managerToken}` },
  });
  assert.equal(users.response.status, 200);
  assert.equal(
    users.payload.data.every((item) =>
      item.role === 'general_user' && String(item.business_group_id) === managerGroupId),
    true,
  );

  for (const [method, url, body] of [
    ['POST', '/api/management/users', {
      name: '无权限新增', phone: `195${Date.now().toString().slice(-8)}`,
      password: 'Denied123!', role: 'general_user', businessGroupId: managerGroupId,
    }],
    ['PUT', '/api/management/users/999999999', { name: '无权限编辑' }],
    ['DELETE', '/api/management/users/999999999', undefined],
  ]) {
    const denied = await request(url, {
      method,
      headers: { Authorization: `Bearer ${managerToken}` },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    assert.equal(denied.response.status, 403);
    assert.equal(denied.payload.code, 'PERMISSION_DENIED');
  }
});

test('only super administrators can access domain configuration', async () => {
  const systemAdminLogin = await request('/api/management/auth/login', {
    method: 'POST',
    body: JSON.stringify({ phone: '13800000002', password: 'Demo123!' }),
  });
  assert.equal(systemAdminLogin.response.status, 200);
  assert.equal(systemAdminLogin.payload.data.user.role, 'system_admin');
  const systemAdminToken = systemAdminLogin.payload.data.token;

  for (const [method, url, body] of [
    ['GET', '/api/domain/list'],
    ['GET', '/api/domain/wechat-config'],
    ['GET', '/api/management/customer-link'],
    ['PUT', '/api/management/customer-link', { url: 'https://customer.example.net' }],
  ]) {
    const denied = await request(url, {
      method,
      headers: { Authorization: `Bearer ${systemAdminToken}` },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    assert.equal(denied.response.status, 403);
    assert.equal(denied.payload.code, 'PERMISSION_DENIED');
  }

  const superAdminDomainList = await request('/api/domain/list');
  assert.equal(superAdminDomainList.response.status, 200);
  assert.ok(Array.isArray(superAdminDomainList.payload.data));
});

test('play page exposes material metadata for WeChat sharing', async () => {
  const title = `分享标题 & <安全> ${runId}`;
  const description = `分享简介 “测试” ${runId}`;
  const coverUrl = 'https://example.net/share-cover.jpg';
  await pool.execute(
    'UPDATE videos SET title = ?, description = ?, cover_url = ? WHERE id = ?',
    [title, description, coverUrl, videoId],
  );
  const response = await fetch(`${baseUrl}/play?fileId=test-${runId}`);
  const html = await response.text();
  assert.equal(response.status, 200);
  assert.match(html, new RegExp(`<title>分享标题 &amp; &lt;安全&gt; ${runId}</title>`));
  assert.match(html, /property="og:title"/);
  assert.match(html, /property="og:description"/);
  assert.match(html, /property="og:image" content="https:\/\/example\.net\/share-cover\.jpg"/);
  assert.match(html, /rel="canonical"/);
  assert.match(html, /itemprop="name"/);
  assert.match(html, /itemprop="description"/);
  assert.match(html, /itemprop="image" content="https:\/\/example\.net\/share-cover\.jpg"/);
  assert.equal(html.includes('<安全>'), false);

  await pool.execute('UPDATE videos SET cover_url = NULL WHERE id = ?', [videoId]);
  const fallbackResponse = await fetch(`${baseUrl}/play?fileId=test-${runId}`);
  const fallbackHtml = await fallbackResponse.text();
  assert.equal(fallbackResponse.status, 200);
  assert.match(
    fallbackHtml,
    /property="og:image" content="http:\/\/127\.0\.0\.1:\d+\/wechat-share-default\.png"/,
  );
  assert.match(fallbackHtml, /property="og:image:width" content="600"/);
});

test('material title and description can be edited', async () => {
  const title = `已编辑素材 ${runId}`;
  const description = `已编辑素材简介 ${runId}`;
  const updated = await request(`/api/management/materials/${videoId}`, {
    method: 'PUT',
    body: JSON.stringify({ title, description }),
  });
  assert.equal(updated.response.status, 200);

  const [[material]] = await pool.execute(
    'SELECT title, description FROM videos WHERE id = ?',
    [videoId],
  );
  assert.deepEqual(material, { title, description });
});

test('card cover images can be replaced and publicly loaded', async () => {
  const png = Buffer.from(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=',
    'base64',
  );
  const formData = new FormData();
  formData.append('cover', new Blob([png], { type: 'image/png' }), 'card-cover.png');
  const uploaded = await request(`/api/management/materials/${videoId}/card-cover`, {
    method: 'POST', body: formData,
  });
  assert.equal(uploaded.response.status, 200);
  assert.match(uploaded.payload.data.coverUrl, /^\/api\/media\/share-cards\/[0-9a-f-]{36}\.png$/);

  const imageResponse = await fetch(`${baseUrl}${uploaded.payload.data.coverUrl}`);
  assert.equal(imageResponse.status, 200);
  assert.match(imageResponse.headers.get('content-type') || '', /^image\/png/);
  assert.deepEqual(Buffer.from(await imageResponse.arrayBuffer()), png);

  const [[material]] = await pool.execute('SELECT cover_url FROM videos WHERE id = ?', [videoId]);
  assert.equal(material.cover_url, uploaded.payload.data.coverUrl);

  await pool.execute('UPDATE videos SET cover_url = NULL WHERE id = ?', [videoId]);
  await removeCardCover(uploaded.payload.data.coverUrl);
});

test('promoters, system admins, and business groups can be edited', async () => {
  const suffix = crypto.randomBytes(4).toString('hex');
  const createdGroup = await request('/api/management/business-groups', {
    method: 'POST',
    body: JSON.stringify({
      name: `验收业务组-${suffix}`,
      managerName: `组管理员-${suffix}`,
      managerPhone: `199${Date.now().toString().slice(-8)}`,
      password: 'EditTest123!',
      expiresAt: null,
    }),
  });
  assert.equal(createdGroup.response.status, 201);
  const groupId = String(createdGroup.payload.data.id);
  cleanupBusinessGroupIds.add(groupId);
  const [[manager]] = await pool.execute(
    'SELECT manager_user_id FROM business_groups WHERE id = ?',
    [groupId],
  );
  cleanupUserIds.add(String(manager.manager_user_id));

  const updatedGroup = await request(`/api/management/business-groups/${groupId}`, {
    method: 'PUT',
    body: JSON.stringify({
      name: `已编辑业务组-${suffix}`,
      managerName: `已编辑管理员-${suffix}`,
      status: 'active',
      expiresAt: '2030-12-31 23:59:59',
    }),
  });
  assert.equal(updatedGroup.response.status, 200);

  const createdPromoter = await request('/api/management/users', {
    method: 'POST',
    body: JSON.stringify({
      name: `推广员-${suffix}`,
      phone: `198${Date.now().toString().slice(-8)}`,
      password: 'EditTest123!',
      role: 'general_user',
      businessGroupId: groupId,
    }),
  });
  assert.equal(createdPromoter.response.status, 201);
  const promoterId = String(createdPromoter.payload.data.id);
  cleanupUserIds.add(promoterId);
  const newPhone = `197${Date.now().toString().slice(-8)}`;
  const updatedPromoter = await request(`/api/management/users/${promoterId}`, {
    method: 'PUT',
    body: JSON.stringify({
      name: `已编辑推广员-${suffix}`,
      phone: newPhone,
      businessGroupId: groupId,
      status: 'active',
      expiresAt: '2030-12-31 23:59:59',
    }),
  });
  assert.equal(updatedPromoter.response.status, 200);

  const createdAdmin = await request('/api/management/users', {
    method: 'POST',
    body: JSON.stringify({
      name: `系统管理员-${suffix}`,
      phone: `196${Date.now().toString().slice(-8)}`,
      password: 'EditTest123!',
      role: 'system_admin',
    }),
  });
  assert.equal(createdAdmin.response.status, 201);
  const adminId = String(createdAdmin.payload.data.id);
  cleanupUserIds.add(adminId);
  const updatedAdmin = await request(`/api/management/users/${adminId}`, {
    method: 'PUT',
    body: JSON.stringify({ name: `已编辑系统管理员-${suffix}`, status: 'active' }),
  });
  assert.equal(updatedAdmin.response.status, 200);

  const groups = await request('/api/management/business-groups');
  const users = await request('/api/management/users');
  const editedGroup = groups.payload.data.find((item) => String(item.id) === groupId);
  const editedPromoter = users.payload.data.find((item) => String(item.id) === promoterId);
  assert.equal(editedGroup.name, `已编辑业务组-${suffix}`);
  assert.equal(editedPromoter.phone, newPhone);
  assert.equal(new Date(editedGroup.expires_at).toISOString(), '2030-12-31T15:59:59.000Z');
  assert.equal(new Date(editedPromoter.expires_at).toISOString(), '2030-12-31T15:59:59.000Z');
  assert.equal(users.payload.data.find((item) => String(item.id) === adminId).name, `已编辑系统管理员-${suffix}`);
});

test('playback start is idempotent and progress is throttled', async () => {
  const sessionId = crypto.randomUUID();
  const event = (eventType, playedSeconds) => request(`/api/video/${videoId}/events`, {
    method: 'POST',
    body: JSON.stringify({ sessionId, eventType, playedSeconds }),
  });
  const firstStart = await event('start', 0);
  const duplicateStart = await event('start', 0.1);
  const firstProgress = await event('progress', 4);
  const throttledProgress = await event('progress', 5);

  assert.equal(firstStart.response.status, 201);
  assert.equal(duplicateStart.response.status, 200);
  assert.equal(duplicateStart.payload.data.duplicate, true);
  assert.equal(firstProgress.response.status, 201);
  assert.equal(throttledProgress.payload.data.throttled, true);

  const [rows] = await pool.execute(
    `SELECT event_type, COUNT(*) AS count
     FROM play_logs WHERE video_id = ? AND session_id = ?
     GROUP BY event_type`,
    [videoId, sessionId],
  );
  assert.deepEqual(
    Object.fromEntries(rows.map((row) => [row.event_type, Number(row.count)])),
    { start: 1, progress: 1 },
  );
});

test('domain CRUD, toggle, primary guards, and validation work', async () => {
  const port = 30000 + Number.parseInt(crypto.randomBytes(2).toString('hex'), 16) % 20000;
  const domain = `http://127.0.0.1:${port}`;
  const created = await request('/api/domain', {
    method: 'POST',
    body: JSON.stringify({
      domain,
      type: 'self_hosted',
      platform: 'self',
      remark: 'created by automated test',
      isEnabled: true,
    }),
  });
  assert.equal(created.response.status, 201);
  const domainId = created.payload.data.id;
  cleanupDomainIds.add(String(domainId));

  const updated = await request(`/api/domain/${domainId}`, {
    method: 'PUT',
    body: JSON.stringify({
      domain,
      type: 'self_hosted',
      platform: 'self',
      remark: 'updated',
      isEnabled: true,
    }),
  });
  assert.equal(updated.response.status, 200);

  const disabled = await request(`/api/domain/${domainId}/toggle`, {
    method: 'POST',
    body: JSON.stringify({ enabled: false }),
  });
  assert.equal(disabled.response.status, 200);

  const switchDisabled = await request('/api/domain/switch', {
    method: 'POST',
    body: JSON.stringify({ domainId }),
  });
  assert.equal(switchDisabled.response.status, 409);

  await request(`/api/domain/${domainId}/toggle`, {
    method: 'POST',
    body: JSON.stringify({ enabled: true }),
  });
  const deleted = await request(`/api/domain/${domainId}`, { method: 'DELETE' });
  assert.equal(deleted.response.status, 200);
  cleanupDomainIds.delete(String(domainId));

  const mismatch = await request('/api/domain', {
    method: 'POST',
    body: JSON.stringify({
      domain: `https://mismatch-${runId}.invalid`,
      type: 'suolink',
      platform: 'self',
    }),
  });
  assert.equal(mismatch.response.status, 400);
  assert.equal(mismatch.payload.code, 'DOMAIN_PLATFORM_MISMATCH');

  const deletePrimary = await request(`/api/domain/${originalPrimaryId}`, {
    method: 'DELETE',
  });
  assert.equal(deletePrimary.response.status, 409);
  assert.equal(deletePrimary.payload.code, 'PRIMARY_DOMAIN_CONFLICT');

  const pathDomain = await request('/api/domain', {
    method: 'POST',
    body: JSON.stringify({
      domain: `${domain}/play`,
      type: 'self_hosted',
      platform: 'self',
    }),
  });
  assert.equal(pathDomain.response.status, 400);
});

test('Suolink settings are optional and API keys are encrypted and masked', async () => {
  const configKeys = ['suolink_api_key', 'suolink_domain', 'suolink_enabled', 'shortlink_platform', 'primary_domain_id'];
  const placeholders = configKeys.map(() => '?').join(',');
  const [originalConfigRows] = await pool.execute(
    `SELECT config_key, config_value FROM system_configs WHERE config_key IN (${placeholders})`,
    configKeys,
  );
  const [originalDomainRows] = await pool.execute(
    'SELECT id, is_primary, is_enabled FROM domains',
  );
  const domain = `s-${crypto.randomBytes(4).toString('hex')}.example.net`;
  const apiKey = `real-key-${crypto.randomBytes(12).toString('hex')}`;
  let createdDomainId;

  try {
    const incomplete = await request('/api/domain/suolink-config', {
      method: 'PUT',
      body: JSON.stringify({ enabled: true, apiKey: '', domain: '' }),
    });
    assert.equal(incomplete.response.status, 400);
    assert.equal(incomplete.payload.code, 'SUOLINK_CONFIG_INCOMPLETE');

    const saved = await request('/api/domain/suolink-config', {
      method: 'PUT',
      body: JSON.stringify({ enabled: true, apiKey, domain }),
    });
    assert.equal(saved.response.status, 200);
    assert.equal(saved.payload.data.enabled, true);
    assert.equal(saved.payload.data.apiKeyConfigured, true);
    assert.equal(saved.payload.data.apiKeyMasked.endsWith(apiKey.slice(-4)), true);
    assert.equal(JSON.stringify(saved.payload).includes(apiKey), false);

    const [[storedKey]] = await pool.execute(
      "SELECT config_value FROM system_configs WHERE config_key = 'suolink_api_key'",
    );
    assert.notEqual(storedKey.config_value, apiKey);
    assert.equal(decryptSecret(storedKey.config_value), apiKey);

    const config = await request('/api/domain/suolink-config');
    assert.equal(config.response.status, 200);
    assert.equal(config.payload.data.domain, domain);
    assert.equal(Object.hasOwn(config.payload.data, 'apiKey'), false);
    assert.equal(JSON.stringify(config.payload).includes(apiKey), false);

    const [[createdDomain]] = await pool.execute(
      "SELECT id FROM domains WHERE domain = ? AND platform = 'suolink'",
      [`https://${domain}`],
    );
    createdDomainId = createdDomain.id;
  } finally {
    if (createdDomainId) await pool.execute('DELETE FROM domains WHERE id = ?', [createdDomainId]);
    await pool.execute(
      `DELETE FROM system_configs WHERE config_key IN (${placeholders})`,
      configKeys,
    );
    for (const row of originalConfigRows) {
      await pool.execute(
        'INSERT INTO system_configs (config_key, config_value) VALUES (?, ?)',
        [row.config_key, row.config_value],
      );
    }
    for (const domainState of originalDomainRows) {
      await pool.execute(
        'UPDATE domains SET is_primary = ?, is_enabled = ? WHERE id = ?',
        [domainState.is_primary, domainState.is_enabled, domainState.id],
      );
    }
  }
});

test('WeChat sharing settings validate the landing domain, encrypt secrets, and drive new links', async () => {
  const configKeys = [
    'wechat_enabled', 'wechat_landing_base_url', 'wechat_app_id', 'wechat_app_secret',
  ];
  const placeholders = configKeys.map(() => '?').join(',');
  const [originalRows] = await pool.execute(
    `SELECT config_key, config_value FROM system_configs WHERE config_key IN (${placeholders})`,
    configKeys,
  );
  const appId = 'wx1234567890abcdef';
  const appSecret = `wechat-secret-${crypto.randomBytes(12).toString('hex')}`;
  const landingBaseUrl = `https://wechat-${crypto.randomBytes(6).toString('hex')}.invalid`;
  const originalEnvAppId = process.env.WECHAT_APP_ID;
  const originalEnvAppSecret = process.env.WECHAT_APP_SECRET;
  const originalCreateSignature = wechatShareService.createSignature;
  const originalCreateShortLink = unifiedShortLinkService.createShortLink;
  let landingDomainId;
  let historicalLandingDomainId;

  try {
    process.env.WECHAT_APP_ID = '';
    process.env.WECHAT_APP_SECRET = '';
    await pool.execute(
      `DELETE FROM system_configs WHERE config_key IN (${placeholders})`,
      configKeys,
    );
    wechatShareService.clearCache();

    const emptyDisabled = await request('/api/domain/wechat-config', {
      method: 'PUT',
      body: JSON.stringify({
        enabled: false, landingBaseUrl: '', appId: '', appSecret: '',
      }),
    });
    assert.equal(emptyDisabled.response.status, 200);
    assert.equal(emptyDisabled.payload.data.enabled, false);
    assert.equal(emptyDisabled.payload.data.landingBaseUrl, '');

    for (const body of [
      { enabled: true, landingBaseUrl: '', appId, appSecret },
      { enabled: true, landingBaseUrl, appId: '', appSecret },
      { enabled: true, landingBaseUrl, appId, appSecret: '' },
    ]) {
      const incomplete = await request('/api/domain/wechat-config', {
        method: 'PUT', body: JSON.stringify(body),
      });
      assert.equal(incomplete.response.status, 400);
      assert.equal(incomplete.payload.code, 'WECHAT_CONFIG_INCOMPLETE');
    }

    for (const invalidLandingBaseUrl of [
      'http://video.example.net',
      'https://video.example.net/play',
      'https://video.example.net?source=wechat',
      'https://user:password@video.example.net',
      'https://video.example.net#wechat',
    ]) {
      const invalid = await request('/api/domain/wechat-config', {
        method: 'PUT',
        body: JSON.stringify({
          enabled: false, landingBaseUrl: invalidLandingBaseUrl, appId: '',
        }),
      });
      assert.equal(invalid.response.status, 400, invalidLandingBaseUrl);
      assert.equal(invalid.payload.code, 'WECHAT_LANDING_URL_INVALID');
    }

    const saved = await request('/api/domain/wechat-config', {
      method: 'PUT',
      body: JSON.stringify({ enabled: true, landingBaseUrl, appId, appSecret }),
    });
    assert.equal(saved.response.status, 200);
    assert.equal(saved.payload.data.enabled, true);
    assert.equal(saved.payload.data.landingBaseUrl, landingBaseUrl);
    assert.equal(saved.payload.data.appId, appId);
    assert.equal(saved.payload.data.appSecretConfigured, true);
    assert.equal(JSON.stringify(saved.payload).includes(appSecret), false);

    const [[stored]] = await pool.execute(
      "SELECT config_value FROM system_configs WHERE config_key = 'wechat_app_secret'",
    );
    assert.notEqual(stored.config_value, appSecret);
    assert.equal(stored.config_value.startsWith('enc:v1:'), true);
    assert.equal(decryptSecret(stored.config_value), appSecret);

    const config = await request('/api/domain/wechat-config');
    assert.equal(config.response.status, 200);
    assert.equal(config.payload.data.landingBaseUrl, landingBaseUrl);
    assert.equal(config.payload.data.appSecretConfigured, true);
    assert.equal(Object.hasOwn(config.payload.data, 'appSecret'), false);
    assert.equal(JSON.stringify(config.payload).includes(appSecret), false);

    const [[landingDomain]] = await pool.execute(
      `SELECT id, type, platform, is_enabled FROM domains WHERE domain = ? LIMIT 1`,
      [landingBaseUrl],
    );
    landingDomainId = landingDomain.id;
    assert.equal(landingDomain.type, 'self_hosted');
    assert.equal(landingDomain.platform, 'self');
    assert.equal(Boolean(landingDomain.is_enabled), true);

    const blockedToggle = await request(`/api/domain/${landingDomainId}/toggle`, {
      method: 'POST', body: JSON.stringify({ enabled: false }),
    });
    assert.equal(blockedToggle.response.status, 409);
    assert.equal(blockedToggle.payload.code, 'WECHAT_LANDING_DOMAIN_REQUIRED');
    const blockedDelete = await request(`/api/domain/${landingDomainId}`, { method: 'DELETE' });
    assert.equal(blockedDelete.response.status, 409);
    assert.equal(blockedDelete.payload.code, 'WECHAT_LANDING_DOMAIN_REQUIRED');

    let signedUrl = '';
    wechatShareService.createSignature = async (url) => {
      signedUrl = url;
      return {
        enabled: true,
        appId,
        timestamp: 1234567890,
        nonceStr: 'acceptance-test',
        signature: 'acceptance-signature',
      };
    };
    const readiness = await request('/api/domain/delivery-readiness');
    assert.equal(readiness.response.status, 200);
    assert.equal(readiness.payload.data.checks.wechatLandingHttps, true);
    assert.equal(readiness.payload.data.checks.wechatLandingInDomainPool, true);
    assert.equal(readiness.payload.data.checks.wechatAppIdConfigured, true);
    assert.equal(readiness.payload.data.checks.wechatAppSecretConfigured, true);
    assert.equal(readiness.payload.data.checks.wechatProviderReachable, true);
    assert.equal(JSON.stringify(readiness.payload).includes(appSecret), false);

    const allowedUrl = `${landingBaseUrl}/play?fileId=test-${runId}`;
    const signature = await request(
      `/api/video/wechat-share-signature?url=${encodeURIComponent(allowedUrl)}`,
    );
    assert.equal(signature.response.status, 200);
    assert.equal(signature.payload.data.enabled, true);
    assert.equal(signedUrl, allowedUrl);

    const historicalLandingBaseUrl = `https://historical-${crypto.randomBytes(6).toString('hex')}.invalid`;
    const [historicalDomainResult] = await pool.execute(
      `INSERT INTO domains
         (domain, type, platform, is_primary, is_enabled, remark)
       VALUES (?, 'self_hosted', 'self', 0, 1, 'historical WeChat landing fixture')`,
      [historicalLandingBaseUrl],
    );
    historicalLandingDomainId = historicalDomainResult.insertId;
    const historicalUrl = `${historicalLandingBaseUrl}/play?fileId=test-${runId}`;
    const historicalSignature = await request(
      `/api/video/wechat-share-signature?url=${encodeURIComponent(historicalUrl)}`,
    );
    assert.equal(historicalSignature.response.status, 200);
    assert.equal(historicalSignature.payload.data.enabled, true);
    assert.equal(signedUrl, historicalUrl);

    const deniedSignature = await request(
      `/api/video/wechat-share-signature?url=${encodeURIComponent('https://other.invalid/play?fileId=test')}`,
    );
    assert.equal(deniedSignature.response.status, 403);
    assert.equal(deniedSignature.payload.code, 'WECHAT_SHARE_DOMAIN_DENIED');

    let generatedLongUrl = '';
    let generatedPlatform = '';
    unifiedShortLinkService.createShortLink = async (longUrl, platform) => {
      generatedLongUrl = longUrl;
      generatedPlatform = platform;
      return {
        id: 999999,
        videoId: String(videoId),
        domainId: String(landingDomainId),
        shortCode: 'WxTest1',
        longUrl,
        shortUrl: 'https://short.invalid/WxTest1',
        platform,
      };
    };
    const generated = await request('/api/shortlink/generate', {
      method: 'POST',
      body: JSON.stringify({
        videoId,
        platform: 'suolink',
        longUrl: `https://old.invalid/play?fileId=test-${runId}`,
      }),
    });
    assert.equal(generated.response.status, 201);
    assert.equal(generatedPlatform, 'suolink');
    const generatedUrl = new URL(generatedLongUrl);
    assert.equal(generatedUrl.origin, landingBaseUrl);
    assert.equal(generatedUrl.pathname, '/play');
    assert.equal(generatedUrl.searchParams.get('fileId'), `test-${runId}`);

    const disabled = await request('/api/domain/wechat-config', {
      method: 'PUT',
      body: JSON.stringify({ enabled: false, landingBaseUrl: '', appId: '' }),
    });
    assert.equal(disabled.response.status, 200);
    assert.equal(disabled.payload.data.landingBaseUrl, '');
  } finally {
    wechatShareService.createSignature = originalCreateSignature;
    unifiedShortLinkService.createShortLink = originalCreateShortLink;
    if (originalEnvAppId === undefined) delete process.env.WECHAT_APP_ID;
    else process.env.WECHAT_APP_ID = originalEnvAppId;
    if (originalEnvAppSecret === undefined) delete process.env.WECHAT_APP_SECRET;
    else process.env.WECHAT_APP_SECRET = originalEnvAppSecret;
    await pool.execute(
      `DELETE FROM system_configs WHERE config_key IN (${placeholders})`,
      configKeys,
    );
    if (historicalLandingDomainId) {
      await pool.execute('DELETE FROM domains WHERE id = ?', [historicalLandingDomainId]);
    }
    if (landingDomainId) await pool.execute('DELETE FROM domains WHERE id = ?', [landingDomainId]);
    for (const row of originalRows) {
      await pool.execute(
        'INSERT INTO system_configs (config_key, config_value) VALUES (?, ?)',
        [row.config_key, row.config_value],
      );
    }
    wechatShareService.clearCache();
  }
});

test('domain pool balances toward the least-used enabled domain', () => {
  const candidates = unifiedShortLinkService.selectCandidates([
    { id: 1, platform: 'self', is_primary: 1, link_count: 4 },
    { id: 2, platform: 'self', is_primary: 0, link_count: 1 },
    { id: 3, platform: 'self', is_primary: 0, link_count: 1 },
    { id: 4, platform: 'self', is_primary: 0, link_count: 7 },
  ], 'self');
  assert.deepEqual(candidates.map((item) => item.id), [2, 3, 1, 4]);

  const primaryTie = unifiedShortLinkService.selectCandidates([
    { id: 5, platform: 'self', is_primary: 0, link_count: 2 },
    { id: 6, platform: 'self', is_primary: 1, link_count: 2 },
  ], 'auto');
  assert.deepEqual(primaryTie.map((item) => item.id), [6, 5]);
});

test('configured Suolink domain cannot be used as a self-hosted code domain', () => {
  const domains = [
    {
      id: 1,
      domain: 'https://w1.hotwharf.com',
      type: 'self_hosted',
      platform: 'self',
    },
    {
      id: 2,
      domain: 'https://vod.hotwharf.com',
      type: 'self_hosted',
      platform: 'self',
    },
  ];

  const enabled = unifiedShortLinkService.reconcileConfiguredSuolinkDomain(domains, {
    enabled: true,
    domain: 'w1.hotwharf.com',
  });
  assert.equal(enabled.find((item) => item.id === 1).platform, 'suolink');
  assert.equal(enabled.find((item) => item.id === 1).type, 'suolink');
  assert.equal(enabled.find((item) => item.id === 1).is_primary, 1);
  assert.equal(enabled.find((item) => item.id === 2).platform, 'self');
  assert.equal(enabled.find((item) => item.id === 2).is_primary, 0);

  const disabled = unifiedShortLinkService.reconcileConfiguredSuolinkDomain(domains, {
    enabled: false,
    domain: 'w1.hotwharf.com',
  });
  assert.deepEqual(disabled.map((item) => item.id), [2]);

  const missingProviderDomain = unifiedShortLinkService.reconcileConfiguredSuolinkDomain(
    domains.slice(1),
    { enabled: true, domain: 'w1.hotwharf.com' },
  );
  assert.deepEqual(missingProviderDomain, []);
});

test('self short links use 6-8 alphanumeric characters', async () => {
  const [[databaseClock]] = await pool.execute(
    'SELECT NOW() AS database_now, @@session.time_zone AS session_time_zone',
  );
  assert.equal(databaseClock.session_time_zone, '+00:00');
  assert.ok(
    Math.abs(new Date(databaseClock.database_now).getTime() - Date.now()) < 5000,
    'database clock should represent the current UTC instant',
  );

  const result = await unifiedShortLinkService.createShortLink(
    `http://localhost:5173/play?fileId=test-${runId}`,
    'self',
    { videoId },
  );
  assert.match(result.shortCode, /^[A-Za-z0-9]{6,8}$/);
  assert.equal(result.platform, 'self');
  const [[createdLink]] = await pool.execute(
    'SELECT created_at FROM short_links WHERE id = ?',
    [result.id],
  );
  assert.ok(
    Math.abs(new Date(createdLink.created_at).getTime() - Date.now()) < 5000,
    'short-link creation time should represent the current UTC instant',
  );

  const cardTitle = `短链卡片 & <安全> ${runId}`;
  const cardDescription = `微信直接抓取短链元数据 ${runId}`;
  await pool.execute(
    'UPDATE videos SET title = ?, description = ?, cover_url = NULL WHERE id = ?',
    [cardTitle, cardDescription, videoId],
  );
  const [[clicksBeforeCardFetch]] = await pool.execute(
    'SELECT clicks FROM short_links WHERE id = ?',
    [result.id],
  );
  const cardResponse = await fetch(`${baseUrl}/api/short/${result.shortCode}`, {
    redirect: 'manual',
    headers: { Accept: 'text/html' },
  });
  const cardHtml = await cardResponse.text();
  assert.equal(cardResponse.status, 200);
  assert.match(cardResponse.headers.get('content-type') || '', /^text\/html/);
  assert.match(cardHtml, new RegExp(`<title>短链卡片 &amp; &lt;安全&gt; ${runId}</title>`));
  assert.match(cardHtml, /property="og:title"/);
  assert.match(cardHtml, /property="og:description"/);
  assert.match(
    cardHtml,
    /property="og:image" content="http:\/\/127\.0\.0\.1:\d+\/wechat-share-default\.png"/,
  );
  assert.match(cardHtml, new RegExp(`shortLinkId=${result.id}`));
  assert.match(cardHtml, /window\.location\.replace\(/);
  assert.equal(cardHtml.includes('<安全>'), false);
  const [[clicksAfterCardFetch]] = await pool.execute(
    'SELECT clicks FROM short_links WHERE id = ?',
    [result.id],
  );
  assert.equal(
    Number(clicksAfterCardFetch.clicks),
    Number(clicksBeforeCardFetch.clicks) + 1,
  );

  await shortLinkService.createShortLink(
    videoId,
    selfDomainId,
    `http://localhost:5173/play?fileId=test-${runId}`,
  );

  const deleteInUse = await request(`/api/domain/${selfDomainId}`, {
    method: 'DELETE',
  });
  assert.equal(deleteInUse.response.status, 409);
  assert.equal(deleteInUse.payload.code, 'DOMAIN_IN_USE');
});

test('suolink failures are classified and auto mode safely falls back', async () => {
  const [domainResult] = await pool.execute(
    `INSERT INTO domains
       (domain, type, platform, is_primary, is_enabled, remark)
     VALUES (?, 'suolink', 'suolink', 1, 1, 'automated provider fixture')`,
    [`https://provider-${runId}.invalid`],
  );
  const suolinkDomainId = domainResult.insertId;
  cleanupDomainIds.add(String(suolinkDomainId));
  await pool.execute('UPDATE domains SET is_primary = (id = ?)', [suolinkDomainId]);

  const originalCreate = suolinkService.createShortLink;
  const providerError = new Error('provider unavailable');
  providerError.code = 'SUOLINK_PROVIDER_ERROR';
  providerError.status = 502;
  suolinkService.createShortLink = async () => {
    throw providerError;
  };

  try {
    const fallback = await unifiedShortLinkService.createShortLink(
      `http://localhost:5173/play?fileId=test-${runId}`,
      'auto',
      { videoId },
    );
    assert.equal(fallback.platform, 'self');
    assert.equal(fallback.fallbackFrom, 'suolink');

    await assert.rejects(
      () => unifiedShortLinkService.createShortLink(
        `http://localhost:5173/play?fileId=test-${runId}`,
        'auto',
        { videoId, allowFallback: false },
      ),
      (error) => error.code === 'SUOLINK_PROVIDER_ERROR' && error.status === 502,
    );

    await assert.rejects(
      () => unifiedShortLinkService.createShortLink(
        `http://localhost:5173/play?fileId=test-${runId}`,
        'suolink',
        { videoId },
      ),
      (error) => error.code === 'SUOLINK_PROVIDER_ERROR' && error.status === 502,
    );
  } finally {
    suolinkService.createShortLink = originalCreate;
    await pool.execute('UPDATE domains SET is_primary = (id = ?)', [originalPrimaryId]);
  }

  assert.throws(
    () => suolinkService.getDomain('your_short_domain.com'),
    (error) => error.code === 'SUOLINK_CONFIG_ERROR' && error.status === 503,
  );
});

test('cloud deletion failure is retryable and repeated deletion is idempotent', async () => {
  const [result] = await pool.execute(
    `INSERT INTO videos (file_id, title, status, expires_at)
     VALUES (?, ?, 'ready', DATE_ADD(NOW(), INTERVAL 1 DAY))`,
    [`delete-${runId}`, `删除验收 ${runId}`],
  );
  const deleteVideoId = result.insertId;
  cleanupVideoIds.add(String(deleteVideoId));
  await pool.execute(
    `INSERT INTO play_logs
       (video_id, session_id, event_type, played_seconds)
     VALUES (?, ?, 'start', 0)`,
    [deleteVideoId, crypto.randomUUID()],
  );

  const originalDelete = vodService.deleteVideo;
  const timeoutError = new Error('cloud timeout');
  timeoutError.code = 'VOD_TIMEOUT';
  timeoutError.status = 503;
  vodService.deleteVideo = async () => {
    throw timeoutError;
  };

  try {
    const failed = await request(`/api/video/${deleteVideoId}`, { method: 'DELETE' });
    assert.equal(failed.response.status, 503);
    const [[afterFailure]] = await pool.execute(
      'SELECT status, delete_error IS NOT NULL AS has_error FROM videos WHERE id = ?',
      [deleteVideoId],
    );
    assert.equal(afterFailure.status, 'ready');
    assert.equal(Number(afterFailure.has_error), 1);

    vodService.deleteVideo = async () => ({ RequestId: 'mocked' });
    const deleted = await request(`/api/video/${deleteVideoId}`, { method: 'DELETE' });
    const repeated = await request(`/api/video/${deleteVideoId}`, { method: 'DELETE' });
    assert.equal(deleted.response.status, 200);
    assert.equal(repeated.response.status, 200);
    assert.equal(repeated.payload.data.alreadyDeleted, true);

    const [[afterDelete]] = await pool.execute(
      `SELECT v.status, v.deleted_at IS NOT NULL AS has_deleted_at,
              v.delete_error IS NULL AS error_cleared,
              (SELECT COUNT(*) FROM play_logs WHERE video_id = v.id) AS audit_logs
       FROM videos v WHERE v.id = ?`,
      [deleteVideoId],
    );
    assert.equal(afterDelete.status, 'deleted');
    assert.equal(Number(afterDelete.has_deleted_at), 1);
    assert.equal(Number(afterDelete.error_cleared), 1);
    assert.equal(Number(afterDelete.audit_logs), 1);
  } finally {
    vodService.deleteVideo = originalDelete;
  }
});

test('expired video access returns HTTP 410 and expires related links', async () => {
  await pool.execute(
    `UPDATE videos SET expires_at = DATE_SUB(NOW(), INTERVAL 1 MINUTE), status = 'ready'
     WHERE id = ?`,
    [videoId],
  );
  const gone = await request(`/api/video/access?fileId=test-${runId}`);
  assert.equal(gone.response.status, 410);
  assert.equal(gone.payload.code, 'VIDEO_EXPIRED');

  const [[mismatch]] = await pool.execute(
    `SELECT COUNT(*) AS count FROM short_links
     WHERE video_id = ? AND status <> 'expired'`,
    [videoId],
  );
  assert.equal(Number(mismatch.count), 0);
});

test('player signature expiration never exceeds the video expiration', () => {
  const maximum = Math.floor(Date.now() / 1000) + 120;
  const token = vodService.createPlayerSignature(
    '123456789',
    new Date(maximum * 1000),
    'Abcd1234Efgh5678',
  );
  const payload = JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString('utf8'));
  assert.equal(payload.appId, Number(process.env.TENCENT_APP_ID));
  assert.ok(payload.expireTimeStamp <= maximum);
});
