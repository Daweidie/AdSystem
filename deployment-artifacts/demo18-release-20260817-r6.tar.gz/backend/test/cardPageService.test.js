const test = require('node:test');
const assert = require('node:assert/strict');
const cardPageService = require('../src/services/cardPageService');

test('card pages render escaped metadata and an encoded same-origin play target', () => {
  const cardToken = 'card-token-12345678901234567890';
  const request = {
    protocol: 'http',
    originalUrl: `/card/${cardToken}?ignored=1`,
    get: () => '127.0.0.1:3000',
  };
  const html = cardPageService.renderCardHtml({
    card_token: cardToken,
    card_title: '<script>alert(1)</script>',
    card_description: '描述 & "引号"',
    card_cover_url: 'http://unsafe.example/cover.jpg',
  }, request, '/play?fileId=demo&shortLinkId=9');

  assert.match(html, /<title>&lt;script&gt;alert\(1\)&lt;\/script&gt;<\/title>/);
  assert.match(html, /property="og:title" content="&lt;script&gt;alert\(1\)&lt;\/script&gt;"/);
  assert.match(html, /property="og:description"/);
  assert.match(html, new RegExp(`property="og:url" content="http://127\\.0\\.0\\.1:3000/card/${cardToken}"`));
  assert.match(html, /property="og:image" content="https:\/\/vod\.hotwharf\.com\/wechat-share-default\.png"/);
  assert.match(html, /name="twitter:title"/);
  assert.match(html, /name="twitter:description"/);
  assert.match(html, /name="twitter:image"/);
  assert.match(html, /window\.location\.assign\(/);
  assert.doesNotMatch(html, /\/play|window\.location\.replace|继续打开|继续播放|<div id="app">/);
  const token = html.match(/data-play-token="([A-Za-z0-9_-]+)"/)?.[1];
  assert.equal(Buffer.from(token, 'base64url').toString('utf8'), '/play?fileId=demo&shortLinkId=9');
  assert.equal(html.includes('<script>alert(1)</script>'), false);
});

test('card tokens are URL-safe and unique', () => {
  const first = cardPageService.createCardToken();
  const second = cardPageService.createCardToken();
  assert.match(first, /^[A-Za-z0-9_-]{40,}$/);
  assert.notEqual(first, second);
});
