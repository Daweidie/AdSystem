import { Context, Hono, Next } from 'hono'
import { cors } from 'hono/cors'
import { csrf } from 'hono/csrf'
import { z } from 'zod'
import { zValidator } from '@hono/zod-validator'
import { nanoid } from 'nanoid'
import { escape } from 'html-escaper'

type Bindings = {
  URL_MAPPINGS: KVNamespace
  URL_ANALYTICS: KVNamespace
  API_KEYS: KVNamespace
  OG_METADATA_CACHE: KVNamespace
  REDIRECT_URL?: string
  ALLOWED_CORS_ORIGINS?: string
  ALLOWED_TARGET_ORIGINS?: string
  DEFAULT_OG_TITLE?: string
  DEFAULT_OG_DESCRIPTION?: string
  DEFAULT_OG_IMAGE?: string
  DEMO18_SYNC_URL?: string
  DEMO18_SYNC_API_KEY?: string
}

type Variables = {
  apiKeyId?: string
}

type WorkerContext = Context<{ Bindings: Bindings; Variables: Variables }>

type StoredUrl = {
  schemaVersion: 2
  shortCode: string
  targetUrl: string
  url: string
  ogTitle: string
  ogDescription: string
  ogImage: string
  ogUrl: string
  expirationDate: number | null
  createdAt: string
  updatedAt: string
  cacheVersion: number
}

const MAX_URL_LENGTH = 2048
const MAX_TITLE_LENGTH = 255
const MAX_DESCRIPTION_LENGTH = 2000
const DEFAULT_TITLE = '视频播放'
const DEFAULT_DESCRIPTION = '点击查看视频素材'
const DEFAULT_IMAGE = 'https://vod.hotwharf.com/wechat-share-default.png'
const SHORT_CODE_PATTERN = /^[A-Za-z0-9_-]{4,64}$/
const CARD_TOKEN_PATH_PATTERN = /^\/card\/[A-Za-z0-9_-]{20,128}\/?$/
const CLICK_SYNC_ATTEMPTS = 3

const createUrlSchema = z.object({
  url: z.string().min(1).max(MAX_URL_LENGTH),
  customCode: z.string().regex(SHORT_CODE_PATTERN).optional(),
  ogTitle: z.string().max(MAX_TITLE_LENGTH).optional(),
  ogDescription: z.string().max(MAX_DESCRIPTION_LENGTH).optional(),
  ogImage: z.string().max(MAX_URL_LENGTH).optional(),
  ogUrl: z.string().max(MAX_URL_LENGTH).optional(),
  expiresIn: z.number().int().min(60).max(31_536_000).optional(),
}).strict()

const updateUrlSchema = z.object({
  targetUrl: z.string().min(1).max(MAX_URL_LENGTH).optional(),
  url: z.string().min(1).max(MAX_URL_LENGTH).optional(),
  ogTitle: z.string().max(MAX_TITLE_LENGTH).optional(),
  ogDescription: z.string().max(MAX_DESCRIPTION_LENGTH).optional(),
  ogImage: z.string().max(MAX_URL_LENGTH).nullable().optional(),
  ogUrl: z.string().max(MAX_URL_LENGTH).optional(),
  expirationDate: z.string().datetime({ offset: true }).nullable().optional(),
}).strict().refine((value) => Object.keys(value).length > 0, {
  message: 'At least one field is required',
})

const app = new Hono<{ Bindings: Bindings; Variables: Variables }>()

function splitConfiguration(value: string | undefined): string[] {
  return String(value || '')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean)
}

function allowedCorsOrigin(origin: string, c: WorkerContext): string {
  if (!origin) return ''
  const allowed = splitConfiguration(c.env.ALLOWED_CORS_ORIGINS)
  return allowed.includes(origin) ? origin : ''
}

app.use('*', cors({
  origin: allowedCorsOrigin,
  allowHeaders: ['Authorization', 'Content-Type'],
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  maxAge: 600,
}))
app.use('/api/*', csrf())

app.onError((error, c) => {
  console.error('worker_request_failed', {
    name: error.name,
    message: String(error.message || 'internal error').slice(0, 300),
  })
  return c.json({ error: 'Internal Server Error' }, 500)
})

app.use('/api/*', async (c, next) => {
  const authorization = c.req.header('Authorization') || ''
  const match = authorization.match(/^Bearer\s+([^\s]+)$/i)
  const token = match?.[1]
  if (!token) return c.json({ error: 'Missing Authorization header' }, 401)

  const apiKey = await c.env.API_KEYS.get(token)
  if (!apiKey) return c.json({ error: 'Invalid API key' }, 401)

  c.set('apiKeyId', 'kv')
  await next()
})

async function rateLimiter(c: WorkerContext, next: Next) {
  const ip = c.req.header('CF-Connecting-IP') || 'unknown'
  const rateLimitKey = `rate_limit:${ip}`
  const current = Number.parseInt(await c.env.URL_ANALYTICS.get(rateLimitKey) || '0', 10)
  if (Number.isFinite(current) && current >= 100) {
    return c.json({ error: 'Too many requests' }, 429)
  }
  await c.env.URL_ANALYTICS.put(rateLimitKey, String((current || 0) + 1), {
    expirationTtl: 60,
  })
  await next()
}

app.use('/api/*', rateLimiter)

function isPrivateHostname(hostname: string): boolean {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, '')
  if (host === 'localhost' || host.endsWith('.localhost') || host === '::1') return true
  if (/^(fc|fd|fe[89ab])[0-9a-f:]*$/i.test(host)) return true

  const match = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/)
  if (!match) return false
  const octets = match.slice(1).map(Number)
  if (octets.some((octet) => octet > 255)) return true
  const [first, second] = octets
  return first === 0
    || first === 10
    || first === 127
    || (first === 100 && second >= 64 && second <= 127)
    || (first === 169 && second === 254)
    || (first === 172 && second >= 16 && second <= 31)
    || (first === 192 && second === 168)
    || (first === 198 && [18, 19].includes(second))
    || first >= 224
}

function parseAbsoluteUrl(
  value: string,
  fieldName: string,
  options: { httpsOnly?: boolean; publicOnly?: boolean } = {},
): URL {
  if (!value || value.length > MAX_URL_LENGTH) {
    throw new Error(`${fieldName} must be between 1 and ${MAX_URL_LENGTH} characters`)
  }

  let url: URL
  try {
    url = new URL(value)
  } catch {
    throw new Error(`${fieldName} must be an absolute URL`)
  }

  const protocols = options.httpsOnly ? ['https:'] : ['http:', 'https:']
  if (!protocols.includes(url.protocol)) {
    throw new Error(`${fieldName} uses an unsupported protocol`)
  }
  if (url.username || url.password) {
    throw new Error(`${fieldName} must not contain credentials`)
  }
  if (options.publicOnly && isPrivateHostname(url.hostname)) {
    throw new Error(`${fieldName} must use a public host`)
  }
  return url
}

function validateTargetUrl(value: string, env: Bindings): string {
  const url = parseAbsoluteUrl(value.trim(), 'url')
  const allowedOrigins = splitConfiguration(env.ALLOWED_TARGET_ORIGINS)
  if (allowedOrigins.length > 0 && !allowedOrigins.includes(url.origin)) {
    throw new Error('url origin is not allowed')
  }
  if (allowedOrigins.length > 0 && !CARD_TOKEN_PATH_PATTERN.test(url.pathname)) {
    throw new Error('url must point to /card/{cardToken}')
  }
  url.hash = ''
  return url.toString()
}

function defaultMetadata(env: Bindings) {
  let image = String(env.DEFAULT_OG_IMAGE || DEFAULT_IMAGE).trim()
  try {
    image = parseAbsoluteUrl(image, 'DEFAULT_OG_IMAGE', {
      httpsOnly: true,
      publicOnly: true,
    }).toString()
  } catch {
    image = DEFAULT_IMAGE
  }

  return {
    ogTitle: String(env.DEFAULT_OG_TITLE || DEFAULT_TITLE).slice(0, MAX_TITLE_LENGTH),
    ogDescription: String(env.DEFAULT_OG_DESCRIPTION || DEFAULT_DESCRIPTION)
      .slice(0, MAX_DESCRIPTION_LENGTH),
    ogImage: image,
  }
}

function normalizeOgImage(value: string | null | undefined, env: Bindings): string {
  const fallback = defaultMetadata(env).ogImage
  if (!value) return fallback

  const raw = value.trim()
  let url: URL
  try {
    url = new URL(raw)
  } catch {
    throw new Error('ogImage must be an absolute URL')
  }
  if (url.protocol === 'http:') return fallback
  if (url.protocol !== 'https:') throw new Error('ogImage uses an unsupported protocol')
  if (url.username || url.password || isPrivateHostname(url.hostname)) {
    throw new Error('ogImage must be a public HTTPS URL')
  }
  return url.toString()
}

function normalizeOgUrl(value: string | undefined, fallback: string): string {
  const url = parseAbsoluteUrl(value || fallback, 'ogUrl', {
    httpsOnly: true,
    publicOnly: true,
  })
  url.hash = ''
  return url.toString()
}

function normalizeExpiration(value: unknown): number | null {
  if (value === null || value === undefined || value === '') return null
  const timestamp = typeof value === 'number' ? value : Date.parse(String(value))
  return Number.isFinite(timestamp) && timestamp > 0 ? timestamp : null
}

function normalizeStoredUrl(
  rawValue: string,
  shortCode: string,
  env: Bindings,
  requestUrl: string,
): StoredUrl | null {
  let raw: Record<string, unknown>
  try {
    raw = JSON.parse(rawValue) as Record<string, unknown>
  } catch {
    return null
  }

  const rawTarget = String(raw.targetUrl || raw.url || '').trim()
  let targetUrl: string
  try {
    targetUrl = validateTargetUrl(rawTarget, env)
  } catch {
    return null
  }

  const defaults = defaultMetadata(env)
  let ogImage: string
  try {
    ogImage = normalizeOgImage(typeof raw.ogImage === 'string' ? raw.ogImage : undefined, env)
  } catch {
    ogImage = defaults.ogImage
  }

  let ogUrl: string
  try {
    ogUrl = normalizeOgUrl(
      typeof raw.ogUrl === 'string' ? raw.ogUrl : undefined,
      requestUrl,
    )
  } catch {
    ogUrl = normalizeOgUrl(undefined, requestUrl)
  }

  const now = new Date().toISOString()
  return {
    schemaVersion: 2,
    shortCode,
    targetUrl,
    url: targetUrl,
    ogTitle: String(raw.ogTitle || defaults.ogTitle).slice(0, MAX_TITLE_LENGTH),
    ogDescription: String(raw.ogDescription || defaults.ogDescription)
      .slice(0, MAX_DESCRIPTION_LENGTH),
    ogImage,
    ogUrl,
    expirationDate: normalizeExpiration(raw.expirationDate),
    createdAt: typeof raw.createdAt === 'string' ? raw.createdAt : now,
    updatedAt: typeof raw.updatedAt === 'string' ? raw.updatedAt : now,
    cacheVersion: Number.isInteger(raw.cacheVersion) && Number(raw.cacheVersion) > 0
      ? Number(raw.cacheVersion)
      : 1,
  }
}

function shortUrlForRequest(requestUrl: string, shortCode: string): string {
  const url = new URL(requestUrl)
  url.pathname = `/${encodeURIComponent(shortCode)}`
  url.search = ''
  url.hash = ''
  return url.toString()
}

function apiResponse(mapping: StoredUrl, requestUrl: string, clickCount: number) {
  return {
    shortCode: mapping.shortCode,
    targetUrl: mapping.targetUrl,
    shortUrl: shortUrlForRequest(requestUrl, mapping.shortCode),
    ogTitle: mapping.ogTitle,
    ogDescription: mapping.ogDescription,
    ogImage: mapping.ogImage,
    ogUrl: mapping.ogUrl,
    clickCount,
    expirationDate: mapping.expirationDate
      ? new Date(mapping.expirationDate).toISOString()
      : null,
    createdAt: mapping.createdAt,
    updatedAt: mapping.updatedAt,
  }
}

async function readClickCount(env: Bindings, shortCode: string): Promise<number> {
  const current = await env.URL_ANALYTICS.get(`clicks:${shortCode}`)
  const legacy = current === null ? await env.URL_ANALYTICS.get(shortCode) : null
  const parsed = Number.parseInt(current ?? legacy ?? '0', 10)
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : 0
}

async function incrementClickCount(env: Bindings, shortCode: string): Promise<number> {
  const next = (await readClickCount(env, shortCode)) + 1
  await env.URL_ANALYTICS.put(`clicks:${shortCode}`, String(next))
  return next
}

function cacheRequest(requestUrl: string, shortCode: string, version: number): Request {
  const url = new URL(requestUrl)
  url.pathname = `/__og_cache/${encodeURIComponent(shortCode)}`
  url.search = `v=${version}`
  url.hash = ''
  return new Request(url.toString(), { method: 'GET' })
}

function workerCache(): Cache | null {
  try {
    return typeof caches === 'undefined' ? null : caches.default
  } catch {
    return null
  }
}

async function purgeHtmlCache(
  requestUrl: string,
  shortCode: string,
  version: number,
): Promise<void> {
  const cache = workerCache()
  if (cache) await cache.delete(cacheRequest(requestUrl, shortCode, version))
}

function trackedTargetUrl(targetUrl: string, shortCode: string): string {
  const target = new URL(targetUrl)
  if (CARD_TOKEN_PATH_PATTERN.test(target.pathname)) {
    target.searchParams.set('_shortCode', shortCode)
  }
  return target.toString()
}

function inlineJsonString(value: string): string {
  return JSON.stringify(value)
    .replaceAll('<', '\\u003c')
    .replaceAll('>', '\\u003e')
    .replaceAll('&', '\\u0026')
    .replaceAll('\u2028', '\\u2028')
    .replaceAll('\u2029', '\\u2029')
}

function renderOgHtml(mapping: StoredUrl): string {
  const targetUrl = trackedTargetUrl(mapping.targetUrl, mapping.shortCode)
  const title = escape(mapping.ogTitle)
  const description = escape(mapping.ogDescription)
  const image = escape(mapping.ogImage)
  const ogUrl = escape(mapping.ogUrl)
  const safeTarget = escape(targetUrl)

  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${title}</title>
  <meta name="description" content="${description}">
  <link rel="canonical" href="${ogUrl}">

  <meta property="og:type" content="website">
  <meta property="og:title" content="${title}">
  <meta property="og:description" content="${description}">
  <meta property="og:image" content="${image}">
  <meta property="og:image:secure_url" content="${image}">
  <meta property="og:url" content="${ogUrl}">
  <meta property="og:image:width" content="600">
  <meta property="og:image:height" content="600">

  <meta name="twitter:card" content="summary_large_image">
</head>
<body>
  <main>
    <h1>${title}</h1>
    <p>${description}</p>
    <a href="${safeTarget}">继续打开</a>
  </main>

  <script>
    window.location.replace(${inlineJsonString(targetUrl)});
  </script>
</body>
</html>`
}

async function synchronizeClick(c: WorkerContext, mapping: StoredUrl): Promise<void> {
  const baseUrl = String(c.env.DEMO18_SYNC_URL || '').trim().replace(/\/+$/, '')
  const apiKey = String(c.env.DEMO18_SYNC_API_KEY || '').trim()
  if (!baseUrl || !apiKey) return

  let endpoint: URL
  try {
    endpoint = new URL(
      `${baseUrl}/api/internal/short-links/${encodeURIComponent(mapping.shortCode)}/click`,
    )
    if (endpoint.protocol !== 'https:' && endpoint.hostname !== '127.0.0.1') return
  } catch {
    return
  }

  const payload = JSON.stringify({
    eventId: crypto.randomUUID(),
    occurredAt: new Date().toISOString(),
    userAgent: String(c.req.header('user-agent') || '').slice(0, 1000),
    referer: String(c.req.header('referer') || '').slice(0, 2048),
    ipAddress: String(c.req.header('CF-Connecting-IP') || '').slice(0, 45),
  })
  let diagnostic = 'request_failed'

  for (let attempt = 0; attempt < CLICK_SYNC_ATTEMPTS; attempt += 1) {
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: payload,
      })
      if (response.ok) return
      diagnostic = `http_${response.status}`
      if (response.status < 500 && response.status !== 429) break
    } catch (error) {
      diagnostic = error instanceof Error ? error.name : 'request_failed'
    }

    if (attempt + 1 < CLICK_SYNC_ATTEMPTS) {
      await new Promise((resolve) => setTimeout(resolve, 50 * 2 ** attempt))
    }
  }

  console.warn('demo18_click_sync_failed', {
    shortCode: mapping.shortCode,
    diagnostic,
  })
}

function scheduleBackground(c: WorkerContext, promise: Promise<unknown>): void {
  try {
    c.executionCtx.waitUntil(promise)
  } catch {
    void promise
  }
}

app.get('/health', (c) => c.json({ status: 'ok' }))

app.get('/', (c) => {
  const redirectUrl = String(c.env.REDIRECT_URL || '').trim()
  if (!redirectUrl) return c.json({ status: 'ok' })
  try {
    return c.redirect(parseAbsoluteUrl(redirectUrl, 'REDIRECT_URL').toString(), 302)
  } catch {
    return c.json({ status: 'ok' })
  }
})

app.post('/api/urls', zValidator('json', createUrlSchema), async (c) => {
  const input = c.req.valid('json')
  let targetUrl: string
  let ogImage: string
  let ogUrl: string
  try {
    targetUrl = validateTargetUrl(input.url, c.env)
    ogImage = normalizeOgImage(input.ogImage, c.env)
    ogUrl = normalizeOgUrl(input.ogUrl, targetUrl)
  } catch (error) {
    return c.json({ error: error instanceof Error ? error.message : 'Invalid URL data' }, 400)
  }

  const shortCode = input.customCode || nanoid(8)
  const existingRaw = await c.env.URL_MAPPINGS.get(shortCode)
  if (existingRaw) {
    const existing = normalizeStoredUrl(
      existingRaw,
      shortCode,
      c.env,
      shortUrlForRequest(c.req.url, shortCode),
    )
    if (!existing || existing.targetUrl !== targetUrl) {
      return c.json({ error: 'Custom code already exists' }, 409)
    }
    return c.json(apiResponse(existing, c.req.url, await readClickCount(c.env, shortCode)), 200)
  }

  const defaults = defaultMetadata(c.env)
  const now = new Date().toISOString()
  const mapping: StoredUrl = {
    schemaVersion: 2,
    shortCode,
    targetUrl,
    url: targetUrl,
    ogTitle: String(input.ogTitle || defaults.ogTitle).slice(0, MAX_TITLE_LENGTH),
    ogDescription: String(input.ogDescription || defaults.ogDescription)
      .slice(0, MAX_DESCRIPTION_LENGTH),
    ogImage,
    ogUrl,
    expirationDate: input.expiresIn ? Date.now() + input.expiresIn * 1000 : null,
    createdAt: now,
    updatedAt: now,
    cacheVersion: 1,
  }
  await c.env.URL_MAPPINGS.put(shortCode, JSON.stringify(mapping))
  return c.json(apiResponse(mapping, c.req.url, 0), 201)
})

app.get('/api/urls/:shortCode', async (c) => {
  const shortCode = c.req.param('shortCode')
  if (!SHORT_CODE_PATTERN.test(shortCode)) return c.json({ error: 'URL not found' }, 404)

  const raw = await c.env.URL_MAPPINGS.get(shortCode)
  if (!raw) return c.json({ error: 'URL not found' }, 404)
  const mapping = normalizeStoredUrl(raw, shortCode, c.env, shortUrlForRequest(c.req.url, shortCode))
  if (!mapping) return c.json({ error: 'URL not found' }, 404)
  if (mapping.expirationDate && mapping.expirationDate <= Date.now()) {
    await Promise.all([
      c.env.URL_MAPPINGS.delete(shortCode),
      purgeHtmlCache(c.req.url, shortCode, mapping.cacheVersion),
    ])
    return c.json({ error: 'URL expired' }, 410)
  }

  return c.json(apiResponse(mapping, c.req.url, await readClickCount(c.env, shortCode)))
})

app.put('/api/urls/:shortCode', zValidator('json', updateUrlSchema), async (c) => {
  const shortCode = c.req.param('shortCode')
  if (!SHORT_CODE_PATTERN.test(shortCode)) return c.json({ error: 'URL not found' }, 404)

  const raw = await c.env.URL_MAPPINGS.get(shortCode)
  if (!raw) return c.json({ error: 'URL not found' }, 404)
  const existing = normalizeStoredUrl(raw, shortCode, c.env, shortUrlForRequest(c.req.url, shortCode))
  if (!existing) return c.json({ error: 'URL not found' }, 404)

  const input = c.req.valid('json')
  let targetUrl = existing.targetUrl
  let ogImage = existing.ogImage
  let ogUrl = existing.ogUrl
  try {
    if (input.targetUrl || input.url) {
      targetUrl = validateTargetUrl(input.targetUrl || input.url || '', c.env)
    }
    if (Object.hasOwn(input, 'ogImage')) ogImage = normalizeOgImage(input.ogImage, c.env)
    if (input.ogUrl) ogUrl = normalizeOgUrl(input.ogUrl, targetUrl)
  } catch (error) {
    return c.json({ error: error instanceof Error ? error.message : 'Invalid URL data' }, 400)
  }

  const mapping: StoredUrl = {
    ...existing,
    targetUrl,
    url: targetUrl,
    ogTitle: input.ogTitle === undefined ? existing.ogTitle : input.ogTitle,
    ogDescription: input.ogDescription === undefined
      ? existing.ogDescription
      : input.ogDescription,
    ogImage,
    ogUrl,
    expirationDate: input.expirationDate === undefined
      ? existing.expirationDate
      : normalizeExpiration(input.expirationDate),
    updatedAt: new Date().toISOString(),
    cacheVersion: existing.cacheVersion + 1,
  }
  await Promise.all([
    c.env.URL_MAPPINGS.put(shortCode, JSON.stringify(mapping)),
    purgeHtmlCache(c.req.url, shortCode, existing.cacheVersion),
  ])
  return c.json(apiResponse(mapping, c.req.url, await readClickCount(c.env, shortCode)))
})

app.delete('/api/urls/:shortCode', async (c) => {
  const shortCode = c.req.param('shortCode')
  const raw = SHORT_CODE_PATTERN.test(shortCode)
    ? await c.env.URL_MAPPINGS.get(shortCode)
    : null
  const existing = raw
    ? normalizeStoredUrl(raw, shortCode, c.env, shortUrlForRequest(c.req.url, shortCode))
    : null

  await Promise.all([
    c.env.URL_MAPPINGS.delete(shortCode),
    c.env.URL_ANALYTICS.delete(`clicks:${shortCode}`),
    c.env.URL_ANALYTICS.delete(shortCode),
    ...(existing
      ? [purgeHtmlCache(c.req.url, shortCode, existing.cacheVersion)]
      : []),
  ])
  return c.json({ shortCode, status: 'deleted' })
})

app.get('/:shortCode', async (c) => {
  const shortCode = c.req.param('shortCode')
  if (!SHORT_CODE_PATTERN.test(shortCode)) return c.notFound()

  const raw = await c.env.URL_MAPPINGS.get(shortCode)
  if (!raw) return c.notFound()
  const mapping = normalizeStoredUrl(raw, shortCode, c.env, shortUrlForRequest(c.req.url, shortCode))
  if (!mapping) return c.notFound()

  if (mapping.expirationDate && mapping.expirationDate <= Date.now()) {
    await Promise.all([
      c.env.URL_MAPPINGS.delete(shortCode),
      purgeHtmlCache(c.req.url, shortCode, mapping.cacheVersion),
    ])
    return c.html('<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><title>链接已失效</title></head><body><main><h1>链接已失效</h1></main></body></html>', 410, {
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
    })
  }

  scheduleBackground(c, incrementClickCount(c.env, shortCode))
  scheduleBackground(c, synchronizeClick(c, mapping))

  const cache = workerCache()
  const cacheKey = cacheRequest(c.req.url, shortCode, mapping.cacheVersion)
  const cached = cache ? await cache.match(cacheKey) : undefined
  if (cached) {
    const headers = new Headers(cached.headers)
    // Keep the per-version Cache API entry, but prevent an outer CDN from
    // serving stale card HTML after metadata is updated.
    headers.set('Cache-Control', 'private, no-store')
    headers.set('CDN-Cache-Control', 'no-store')
    return new Response(cached.body, { status: 200, headers })
  }

  const html = renderOgHtml(mapping)
  const headers = new Headers({
    'Content-Type': 'text/html; charset=UTF-8',
    'Cache-Control': 'private, no-store',
    'CDN-Cache-Control': 'no-store',
    'Content-Security-Policy': "default-src 'none'; script-src 'unsafe-inline'; style-src 'none'; img-src https:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
    'Referrer-Policy': 'no-referrer',
    'X-Content-Type-Options': 'nosniff',
  })
  if (cache) {
    const cacheHeaders = new Headers(headers)
    cacheHeaders.set('Cache-Control', 'public, max-age=300')
    scheduleBackground(c, cache.put(cacheKey, new Response(html, {
      status: 200,
      headers: cacheHeaders,
    })))
  }
  return new Response(html, { status: 200, headers })
})

app.notFound((c) => {
  if (new URL(c.req.url).pathname.startsWith('/api/')) {
    return c.json({ error: 'Not Found' }, 404)
  }
  return c.html('<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><title>链接不存在</title></head><body><main><h1>链接不存在</h1></main></body></html>', 404, {
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  })
})

export {
  app,
  isPrivateHostname,
  normalizeStoredUrl,
  renderOgHtml,
  trackedTargetUrl,
}

export default app
