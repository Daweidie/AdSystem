import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { app } from '../src/index'

class MemoryKv {
  values = new Map<string, string>()

  async get(key: string) {
    return this.values.get(key) ?? null
  }

  async put(key: string, value: string) {
    this.values.set(key, value)
  }

  async delete(key: string) {
    this.values.delete(key)
  }

  async list(options: { prefix?: string } = {}) {
    const keys = [...this.values.keys()]
      .filter((key) => !options.prefix || key.startsWith(options.prefix))
      .map((name) => ({ name }))
    return { keys, list_complete: true, cacheStatus: null }
  }
}

class MemoryCache {
  values = new Map<string, Response>()
  deleted: string[] = []

  key(request: RequestInfo | URL) {
    return typeof request === 'string'
      ? request
      : request instanceof URL
        ? request.toString()
        : request.url
  }

  async match(request: RequestInfo | URL) {
    return this.values.get(this.key(request))?.clone()
  }

  async put(request: RequestInfo | URL, response: Response) {
    this.values.set(this.key(request), response.clone())
  }

  async delete(request: RequestInfo | URL) {
    const key = this.key(request)
    this.deleted.push(key)
    return this.values.delete(key)
  }
}

const CARD_TOKEN = 'abcdefghijklmnopqrstuvwxyz_ABCDEFG1234567890'
const CARD_URL = `https://vod.hotwharf.com/card/${CARD_TOKEN}`
const DEFAULT_IMAGE = 'https://vod.hotwharf.com/wechat-share-default.png'

let mappings: MemoryKv
let analytics: MemoryKv
let apiKeys: MemoryKv
let metadata: MemoryKv
let cache: MemoryCache
let backgroundTasks: Promise<unknown>[]

function environment() {
  return {
    URL_MAPPINGS: mappings,
    URL_ANALYTICS: analytics,
    API_KEYS: apiKeys,
    OG_METADATA_CACHE: metadata,
    ALLOWED_CORS_ORIGINS: 'https://admin.hotwharf.com',
    ALLOWED_TARGET_ORIGINS: 'https://vod.hotwharf.com',
    DEFAULT_OG_TITLE: '默认标题',
    DEFAULT_OG_DESCRIPTION: '默认简介',
    DEFAULT_OG_IMAGE: DEFAULT_IMAGE,
    DEMO18_SYNC_URL: '',
    DEMO18_SYNC_API_KEY: '',
  } as never
}

function executionContext() {
  return {
    waitUntil(promise: Promise<unknown>) {
      backgroundTasks.push(promise)
    },
    passThroughOnException() {},
  } as ExecutionContext
}

async function request(path: string, init: RequestInit = {}) {
  return app.request(
    `https://s.hotwharf.com${path}`,
    init,
    environment(),
    executionContext(),
  )
}

async function api(path: string, init: RequestInit = {}) {
  return request(path, {
    ...init,
    headers: {
      Authorization: 'Bearer test-service-key',
      'Content-Type': 'application/json',
      ...init.headers,
    },
  })
}

async function settleBackgroundTasks() {
  await Promise.all(backgroundTasks.splice(0))
}

beforeEach(async () => {
  mappings = new MemoryKv()
  analytics = new MemoryKv()
  apiKeys = new MemoryKv()
  metadata = new MemoryKv()
  cache = new MemoryCache()
  backgroundTasks = []
  await apiKeys.put('test-service-key', 'true')
  Object.defineProperty(globalThis, 'caches', {
    configurable: true,
    value: { default: cache },
  })
})

afterEach(async () => {
  await settleBackgroundTasks()
  Reflect.deleteProperty(globalThis, 'caches')
})

describe('URL management API', () => {
  it('creates and reads a short URL with complete OG metadata', async () => {
    const response = await api('/api/urls', {
      method: 'POST',
      body: JSON.stringify({
        url: CARD_URL,
        customCode: 'Abc123',
        ogTitle: '卡片标题',
        ogDescription: '卡片简介',
        ogImage: 'https://vod.hotwharf.com/cover.jpg',
        ogUrl: CARD_URL,
        expiresIn: 86400,
      }),
    })
    expect(response.status).toBe(201)
    const created = await response.json<Record<string, unknown>>()
    expect(created).toMatchObject({
      shortCode: 'Abc123',
      shortUrl: 'https://s.hotwharf.com/Abc123',
      targetUrl: CARD_URL,
      ogTitle: '卡片标题',
      ogDescription: '卡片简介',
      ogImage: 'https://vod.hotwharf.com/cover.jpg',
      ogUrl: CARD_URL,
      clickCount: 0,
    })

    const fetched = await api('/api/urls/Abc123')
    expect(fetched.status).toBe(200)
    expect(await fetched.json()).toMatchObject(created)
  })

  it('uses safe defaults when OG fields or legacy fields are missing', async () => {
    const created = await api('/api/urls', {
      method: 'POST',
      body: JSON.stringify({ url: CARD_URL, customCode: 'Default1' }),
    })
    expect(await created.json()).toMatchObject({
      ogTitle: '默认标题',
      ogDescription: '默认简介',
      ogImage: DEFAULT_IMAGE,
    })

    await mappings.put('Legacy1', JSON.stringify({ url: CARD_URL }))
    const legacy = await request('/Legacy1', {
      headers: { 'User-Agent': 'MicroMessenger' },
    })
    expect(legacy.status).toBe(200)
    const html = await legacy.text()
    expect(html).toContain('<meta property="og:title" content="默认标题">')
    expect(html).toContain(`content="${DEFAULT_IMAGE}"`)
  })

  it('rejects dangerous protocols and downgrades HTTP images to the safe default', async () => {
    for (const url of ['javascript:alert(1)', 'data:text/html,hello', 'file:///tmp/a']) {
      const response = await api('/api/urls', {
        method: 'POST',
        body: JSON.stringify({ url, customCode: 'BadUrl1' }),
      })
      expect(response.status).toBe(400)
    }

    const dataImage = await api('/api/urls', {
      method: 'POST',
      body: JSON.stringify({ url: CARD_URL, customCode: 'BadImg1', ogImage: 'data:image/png;base64,abc' }),
    })
    expect(dataImage.status).toBe(400)

    const privateImage = await api('/api/urls', {
      method: 'POST',
      body: JSON.stringify({ url: CARD_URL, customCode: 'Private1', ogImage: 'https://127.0.0.1/a.jpg' }),
    })
    expect(privateImage.status).toBe(400)

    const httpImage = await api('/api/urls', {
      method: 'POST',
      body: JSON.stringify({ url: CARD_URL, customCode: 'HttpImg', ogImage: 'http://example.com/a.jpg' }),
    })
    expect(await httpImage.json()).toMatchObject({ ogImage: DEFAULT_IMAGE })
  })

  it('requires an API key and enforces the configured target origin and card path', async () => {
    const unauthenticated = await request('/api/urls/Abc123')
    expect(unauthenticated.status).toBe(401)

    for (const url of [
      'https://evil.example/card/abcdefghijklmnopqrstuvwxyz123456',
      'https://vod.hotwharf.com/play?fileId=1',
    ]) {
      const response = await api('/api/urls', {
        method: 'POST',
        body: JSON.stringify({ url, customCode: 'Denied1' }),
      })
      expect(response.status).toBe(400)
    }
  })

  it('updates fields, bumps the cache version, purges old HTML, and deletes idempotently', async () => {
    await api('/api/urls', {
      method: 'POST',
      body: JSON.stringify({ url: CARD_URL, customCode: 'Update1', ogTitle: '旧标题' }),
    })
    await request('/Update1')
    await settleBackgroundTasks()
    expect(cache.values.size).toBe(1)

    const updated = await api('/api/urls/Update1', {
      method: 'PUT',
      body: JSON.stringify({
        ogTitle: '新标题',
        ogDescription: '新简介',
        ogImage: 'https://vod.hotwharf.com/new.webp',
        ogUrl: 'https://s.hotwharf.com/Update1',
      }),
    })
    expect(updated.status).toBe(200)
    expect(await updated.json()).toMatchObject({ ogTitle: '新标题' })
    expect(cache.deleted.some((key) => key.includes('v=1'))).toBe(true)

    const html = await (await request('/Update1')).text()
    expect(html).toContain('<title>新标题</title>')
    expect(html).not.toContain('<title>旧标题</title>')

    expect((await api('/api/urls/Update1', { method: 'DELETE' })).status).toBe(200)
    expect((await api('/api/urls/Update1', { method: 'DELETE' })).status).toBe(200)
    expect((await request('/Update1')).status).toBe(404)
  })
})

describe('public OG HTML', () => {
  async function createXssFixture() {
    return api('/api/urls', {
      method: 'POST',
      body: JSON.stringify({
        url: `${CARD_URL}?next=%27%3C%2Fscript%3E%3Cscript%3Ealert(9)%3C%2Fscript%3E`,
        customCode: 'Safe123',
        ogTitle: '<script>alert(1)</script> & "标题"',
        ogDescription: '描述 <img src=x onerror=alert(2)>',
        ogImage: 'https://vod.hotwharf.com/cover.jpg',
        ogUrl: 'https://s.hotwharf.com/Safe123',
      }),
    })
  }

  it('returns the same complete HTTP 200 HTML for every requested User-Agent', async () => {
    await createXssFixture()
    for (const userAgent of [
      'MicroMessenger',
      'WeChat',
      'Mozilla/5.0',
      'facebookexternalhit',
      'Twitterbot',
    ]) {
      const response = await request('/Safe123', { headers: { 'User-Agent': userAgent } })
      expect(response.status).toBe(200)
      expect(response.headers.get('content-type')).toContain('text/html')
      const html = await response.text()
      expect(html).toContain('<!doctype html>')
      expect(html).toContain('<meta property="og:title"')
      expect(html).toContain('<meta property="og:description"')
      expect(html).toContain('<meta property="og:image"')
      expect(html).toContain('<meta property="og:image:secure_url"')
      expect(html).toContain('<meta name="twitter:card" content="summary_large_image">')
      expect(html).toContain('<a href=')
      expect(html).toContain('继续打开')
      expect(html).toContain('window.location.replace(')
    }
  })

  it('escapes HTML and safely JSON-encodes the JavaScript redirect', async () => {
    await createXssFixture()
    const html = await (await request('/Safe123')).text()
    expect(html).toContain('&lt;script&gt;alert(1)&lt;/script&gt; &amp; &quot;标题&quot;')
    expect(html).toContain('描述 &lt;img src=x onerror=alert(2)&gt;')
    expect(html).not.toContain('<script>alert(1)</script>')
    expect(html).not.toContain('<img src=x onerror=alert(2)>')
    expect(html).not.toContain('</script><script>alert(9)</script>')
    expect(html).toContain('%27%3C%2Fscript%3E%3Cscript%3Ealert%289%29%3C%2Fscript%3E')
    expect(html).toContain('_shortCode=Safe123')
  })

  it('counts access and returns 410/404 for expired or malformed records', async () => {
    await api('/api/urls', {
      method: 'POST',
      body: JSON.stringify({ url: CARD_URL, customCode: 'Clicks1' }),
    })
    expect((await request('/Clicks1')).status).toBe(200)
    await settleBackgroundTasks()
    const detail = await (await api('/api/urls/Clicks1')).json<{ clickCount: number }>()
    expect(detail.clickCount).toBe(1)

    await mappings.put('Expired1', JSON.stringify({
      url: CARD_URL,
      expirationDate: Date.now() - 1000,
    }))
    expect((await request('/Expired1')).status).toBe(410)
    expect(await mappings.get('Expired1')).toBeNull()

    await mappings.put('Broken1', '{not-json')
    expect((await request('/Broken1')).status).toBe(404)
    expect((await request('/Missing1')).status).toBe(404)
  })
})
