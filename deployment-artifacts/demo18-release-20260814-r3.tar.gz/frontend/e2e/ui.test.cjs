const assert = require('node:assert/strict');
const { chromium } = require('playwright-core');

const edgePath = process.env.PLAYWRIGHT_EDGE_PATH ||
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const baseUrl = process.env.E2E_BASE_URL || 'http://localhost:5173';
const apiBaseUrl = (process.env.E2E_API_BASE_URL || 'http://localhost:3001/api').replace(/\/$/, '');

async function login(page, phone) {
  await page.goto(baseUrl, { waitUntil: 'networkidle', timeout: 60000 });
  await page.getByPlaceholder('请输入登录手机号').fill(phone);
  await page.getByPlaceholder('请输入登录密码').fill('Demo123!');
  await page.getByRole('button', { name: '登录系统' }).click();
  await page.waitForURL('**/admin', { timeout: 30000 });
  await page.getByText('今日工作台').waitFor({ state: 'visible' });
}

(async () => {
  const browser = await chromium.launch({ executablePath: edgePath, headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
    await page.goto(baseUrl, { waitUntil: 'networkidle', timeout: 60000 });
    assert.equal(await page.title(), '视频广告资源管理系统');
    assert.equal(await page.getByText('TENCENT CLOUD VOD', { exact: true }).count(), 0);
    assert.equal(await page.getByText(/演示账号/).count(), 0);
    assert.equal(await page.getByPlaceholder('请输入登录手机号').inputValue(), '');
    assert.equal(await page.getByPlaceholder('请输入登录密码').inputValue(), '');
    await login(page, '13800000001');

    for (const label of ['素材资源管理', '推广员管理', '系统管理员']) {
      assert.equal(await page.getByRole('heading', { name: new RegExp(label) }).count(), 1);
    }
    for (const label of ['我的素材列表', '素材组管理', '上传素材', '推广员列表', '业务组列表', '管理员列表']) {
      assert.equal(await page.getByRole('button', { name: label, exact: true }).count(), 1, `missing menu: ${label}`);
    }

    await page.getByRole('button', { name: '我的素材列表', exact: true }).click();
    await page.locator('.material-card').first().waitFor({ state: 'visible' });
    const firstMaterialTitle = await page.locator('.material-card h3').first().innerText();
    await page.locator('.material-card').first().getByRole('button', { name: '编辑', exact: true }).click();
    assert.equal(await page.getByRole('dialog', { name: '编辑素材' }).count(), 1);
    assert.equal(await page.getByRole('dialog', { name: '编辑素材' }).getByPlaceholder('请输入素材名称').inputValue(), firstMaterialTitle);
    await page.getByRole('dialog', { name: '编辑素材' }).getByRole('button', { name: '取消' }).click();
    await page.locator('.material-card').first().getByRole('button', { name: '推广链接' }).click();
    assert.ok(await page.locator('.link-panel').first().isVisible());
    assert.ok(await page.getByRole('button', { name: '复制链接' }).count() >= 1);
    await page.locator('.link-panel').first().getByRole('button', { name: '生成卡片' }).first().click();
    const shareCardDialog = page.getByRole('dialog', { name: '微信卡片设置' });
    assert.equal(await shareCardDialog.count(), 1);
    assert.equal(await shareCardDialog.getByText('效果预览', { exact: true }).count(), 1);
    assert.equal(await shareCardDialog.getByRole('button', { name: '保存并复制卡片链接' }).count(), 1);
    await shareCardDialog.getByRole('button', { name: '取消' }).click();

    await page.getByRole('button', { name: '域名池管理', exact: true }).click();
    assert.equal(await page.getByText('Suolink 第三方缩链', { exact: true }).count(), 1);
    assert.equal(await page.getByRole('button', { name: '保存缩链设置', exact: true }).count(), 1);
    for (const domain of ['iq1k.cn', 'm6z.cn', 'i6q.cn']) {
      assert.equal(await page.getByRole('button', { name: domain, exact: true }).count(), 1);
    }
    assert.equal(await page.getByText('微信公众号分享卡片', { exact: true }).count(), 1);
    assert.equal(await page.getByPlaceholder('https://video.example.com').count(), 1);
    assert.equal(await page.getByText('启用前操作说明', { exact: true }).count(), 1);
    assert.equal(await page.getByText(/JS接口安全域名/).count(), 1);
    assert.equal(await page.getByText(/公众号 IP 白名单/).count(), 1);
    assert.equal(await page.getByRole('button', { name: '保存微信设置', exact: true }).count(), 1);
    assert.equal(await page.getByRole('button', { name: '一键检测', exact: true }).count(), 1);

    await page.getByRole('button', { name: '上传素材', exact: true }).first().click();
    assert.equal(await page.getByText('归属与授权', { exact: true }).count(), 1);
    assert.equal(await page.getByText('选择视频文件', { exact: true }).count(), 1);
    assert.equal(await page.getByRole('button', { name: '保存素材', exact: true }).count(), 1);

    await page.getByRole('button', { name: '退出', exact: true }).click();
    await login(page, '13800000002');
    assert.equal(await page.getByRole('button', { name: '域名池管理', exact: true }).count(), 0);
    assert.equal(await page.getByRole('heading', { name: /系统设置/ }).count(), 0);

    await page.getByRole('button', { name: '退出', exact: true }).click();
    await login(page, '13800000003');
    assert.equal(await page.locator('.metric-card').filter({ hasText: /^业务组/ }).count(), 0);
    assert.equal(await page.getByRole('button', { name: '添加推广员', exact: true }).count(), 0);
    assert.equal(await page.locator('.permission-note').count(), 0);
    await page.getByRole('button', { name: '推广员列表', exact: true }).click();
    assert.equal(await page.locator('.data-table th').filter({ hasText: /^操作$/ }).count(), 0);
    assert.equal(await page.locator('.data-table .table-actions').count(), 0);

    await page.getByRole('button', { name: '退出', exact: true }).click();
    await login(page, '13800000004');
    assert.equal(await page.getByRole('button', { name: '素材组管理', exact: true }).count(), 0);
    assert.equal(await page.getByRole('button', { name: '上传素材', exact: true }).count(), 0);
    assert.equal(await page.getByRole('heading', { name: /系统管理员/ }).count(), 0);
    assert.equal(await page.getByText('一般用户').count() > 0, true);

    const apiVideo = await (await fetch(`${apiBaseUrl}/video/5001834815472845728`)).json();
    assert.equal(apiVideo.success, true);
    const playPage = await browser.newPage();
    const navigation = await playPage.goto(
      `${baseUrl}/play?fileId=5001834815472845728`,
      { waitUntil: 'domcontentloaded', timeout: 60000 },
    );
    assert.equal(navigation.status(), 200);
    await playPage.waitForFunction(() => {
      const element = document.querySelector('video');
      return element && element.readyState >= 2 && element.videoWidth > 0;
    }, null, { timeout: 30000 });

    const wechatPage = await browser.newPage({
      viewport: { width: 390, height: 844 },
      userAgent: 'Mozilla/5.0 MicroMessenger/8.0.50',
    });
    await wechatPage.addInitScript(() => {
      window.__wechatShareTest = { calls: [] };
      window.wx = {
        config(options) { window.__wechatShareTest.config = options; },
        ready(callback) { callback(); },
        error(callback) { window.__wechatShareTest.errorHandlerRegistered = typeof callback === 'function'; },
        updateAppMessageShareData(data) { window.__wechatShareTest.calls.push(['app', data]); },
        updateTimelineShareData(data) { window.__wechatShareTest.calls.push(['timeline', data]); },
        onMenuShareAppMessage(data) { window.__wechatShareTest.calls.push(['legacy-app', data]); },
        onMenuShareTimeline(data) { window.__wechatShareTest.calls.push(['legacy-timeline', data]); },
      };
      window.TCPlayer = () => ({ on() {}, dispose() {}, currentTime() { return 0; } });
    });
    await wechatPage.route('**/api/video/wechat-share-signature**', async (route) => {
      const signedUrl = new URL(route.request().url()).searchParams.get('url');
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          success: true,
          data: {
            enabled: true,
            appId: 'wx1234567890abcdef',
            timestamp: 1234567890,
            nonceStr: 'wechat-card-test',
            signature: 'test-signature',
            url: signedUrl,
          },
        }),
      });
    });
    await wechatPage.goto(
      `${baseUrl}/play?fileId=5001834815472845728`,
      { waitUntil: 'domcontentloaded', timeout: 60000 },
    );
    await wechatPage.waitForFunction(() => window.__wechatShareTest?.calls.length === 4);
    const shareTest = await wechatPage.evaluate(() => window.__wechatShareTest);
    assert.deepEqual(
      [...shareTest.config.jsApiList].sort(),
      [
        'onMenuShareAppMessage', 'onMenuShareTimeline',
        'showMenuItems', 'showOptionMenu',
        'updateAppMessageShareData', 'updateTimelineShareData',
      ].sort(),
    );
    assert.deepEqual(shareTest.calls.map(([name]) => name).sort(), [
      'app', 'legacy-app', 'legacy-timeline', 'timeline',
    ]);
    assert.equal(shareTest.calls.every(([, data]) => /^https?:\/\//.test(data.link)), true);
    assert.equal(shareTest.errorHandlerRegistered, true);

    console.log(JSON.stringify({
      success: true,
      superAdminMenusVerified: true,
      systemAdminDomainRestrictionVerified: true,
      businessManagerReadOnlyVerified: true,
      generalUserRestrictionsVerified: true,
      wechatShareCompatibilityVerified: true,
      materialTitle: firstMaterialTitle,
      publicPlaybackVerified: true,
    }));
  } finally {
    await browser.close();
  }
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
