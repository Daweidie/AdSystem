const pool = require('../config/db');
const shortLinkService = require('../services/shortLinkService');
const suolinkService = require('../services/suolinkService');
const unifiedShortLinkService = require('../services/unifiedShortLinkService');
const cloudflareShortLinkService = require('../services/cloudflareShortLinkService');
const logger = require('../utils/logger');
const {
  getPlayPageBaseUrl,
} = require('../services/runtimeConfigService');
const {
  createCardToken,
  buildCardUrl,
  buildPlayUrl: buildCardPlayUrl,
  renderCardHtml,
  toPublicHttpsUrl,
} = require('../services/cardPageService');

function createHttpError(status, message, code) {
  const error = new Error(message);
  error.status = status;
  error.code = code;
  return error;
}

function normalizeId(value, fieldName) {
  if (!/^\d+$/.test(String(value)) || BigInt(value) <= 0n) {
    throw createHttpError(400, `${fieldName} 必须是正整数`, 'VALIDATION_ERROR');
  }

  return String(value);
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function absoluteHttpUrl(value, req) {
  const raw = String(value || '').trim();
  if (!raw) return '';

  try {
    const url = new URL(raw, `${req.protocol}://${req.get('host')}`);
    return ['http:', 'https:'].includes(url.protocol) ? url.toString() : '';
  } catch {
    return '';
  }
}

function currentRequestPageUrl(req) {
  const requestUrl = new URL(
    req.originalUrl || req.url || '/',
    `${req.protocol}://${req.get('host')}`,
  );
  requestUrl.search = '';
  requestUrl.hash = '';
  return requestUrl.toString();
}

function inlineJsonString(value) {
  return JSON.stringify(String(value || ''))
    .replaceAll('<', '\\u003c')
    .replaceAll('>', '\\u003e')
    .replaceAll('&', '\\u0026')
    .replaceAll('\u2028', '\\u2028')
    .replaceAll('\u2029', '\\u2029');
}

function renderShortLinkCardPage(target, req, redirectUrl) {
  const title = String(target.cardTitle || target.title || '视频播放').slice(0, 255);
  const description = String(
    target.cardDescription || target.description || '点击查看视频素材',
  ).slice(0, 2000);
  // Nginx 会把公开的 /:code 重写到 /api/short/:code，必须使用数据库中保存的
  // 原始短链，避免微信卡片展示内部 API 路径。
  const shareUrl = absoluteHttpUrl(target.shortUrl || req.originalUrl, req);
  const coverUrl = toPublicHttpsUrl(target.cardCoverUrl || target.coverUrl, req);
  const redirectTarget = redirectUrl.toString();

  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>${escapeHtml(title)}</title>
  <meta name="description" content="${escapeHtml(description)}" />
  <link rel="canonical" href="${escapeHtml(shareUrl)}" />
  <meta property="og:type" content="website" />
  <meta property="og:title" content="${escapeHtml(title)}" />
  <meta property="og:description" content="${escapeHtml(description)}" />
  <meta property="og:url" content="${escapeHtml(shareUrl)}" />
  <meta property="og:image" content="${escapeHtml(coverUrl)}" />
  <meta property="og:image:secure_url" content="${escapeHtml(coverUrl)}" />
  <meta property="og:image:width" content="600" />
  <meta property="og:image:height" content="600" />
  <meta itemprop="name" content="${escapeHtml(title)}" />
  <meta itemprop="description" content="${escapeHtml(description)}" />
  <meta itemprop="image" content="${escapeHtml(coverUrl)}" />
  <meta name="twitter:card" content="summary_large_image" />
  <style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#05070a;color:#e2e8f0;font-family:system-ui,sans-serif}.panel{text-align:center;padding:32px}h1{font-size:20px;margin:0 0 10px}p{color:#94a3b8;margin:0 0 18px}a{color:#5eead4}</style>
</head>
<body>
  <main class="panel"><h1>${escapeHtml(title)}</h1><p>${escapeHtml(description)}</p><a href="${escapeHtml(redirectTarget)}">继续打开</a></main>
  <script>window.location.replace(${inlineJsonString(redirectTarget)});</script>
</body>
</html>`;
}

function buildSelfPlayPath(fileId, shortLinkId) {
  const query = new URLSearchParams({
    fileId: String(fileId),
    shortLinkId: String(shortLinkId),
  });
  return `/play?${query.toString()}`;
}

function renderSelfShortLinkCardPage(target, req) {
  const title = String(target.cardTitle || target.title || '视频播放').slice(0, 255);
  const description = String(
    target.cardDescription || target.description || '点击查看视频素材',
  ).slice(0, 2000);
  // The card URL is request-specific metadata. Do not trust a persisted short_url here:
  // an old domain or legacy path would make WeChat cache the wrong canonical card.
  const shareUrl = currentRequestPageUrl(req);
  const coverUrl = toPublicHttpsUrl(target.cardCoverUrl || target.coverUrl, req);
  const playPath = buildSelfPlayPath(target.fileId, target.shortLinkId);
  const playToken = Buffer.from(playPath, 'utf8').toString('base64url');

  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>${escapeHtml(title)}</title>
  <meta name="description" content="${escapeHtml(description)}" />
  <link rel="canonical" href="${escapeHtml(shareUrl)}" />
  <meta property="og:type" content="website" />
  <meta property="og:title" content="${escapeHtml(title)}" />
  <meta property="og:description" content="${escapeHtml(description)}" />
  <meta property="og:image" content="${escapeHtml(coverUrl)}" />
  <meta property="og:image:secure_url" content="${escapeHtml(coverUrl)}" />
  <meta property="og:image:width" content="600" />
  <meta property="og:image:height" content="600" />
  <meta property="og:url" content="${escapeHtml(shareUrl)}" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="${escapeHtml(title)}" />
  <meta name="twitter:description" content="${escapeHtml(description)}" />
  <meta name="twitter:image" content="${escapeHtml(coverUrl)}" />
  <style>
    *{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#070b14;color:#e2e8f0;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}.card{width:min(560px,100%);overflow:hidden;border:1px solid #1e293b;border-radius:20px;background:#0f172a;box-shadow:0 24px 70px rgba(0,0,0,.35)}.cover{display:block;width:100%;aspect-ratio:16/9;object-fit:cover;background:#111827}.content{padding:24px}h1{margin:0 0 10px;font-size:24px;line-height:1.35}p{margin:0 0 18px;color:#94a3b8;line-height:1.7;white-space:pre-wrap}.opening{display:flex;align-items:center;gap:10px;color:#5eead4;font-size:14px}.spinner{width:16px;height:16px;border:2px solid rgba(94,234,212,.25);border-top-color:#5eead4;border-radius:50%;animation:spin .7s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}
  </style>
</head>
<body data-play-token="${playToken}">
  <main class="card">
    <img class="cover" src="${escapeHtml(coverUrl)}" alt="${escapeHtml(title)}" />
    <section class="content">
      <h1>${escapeHtml(title)}</h1>
      <p>${escapeHtml(description)}</p>
      <div class="opening" role="status"><span class="spinner" aria-hidden="true"></span>正在打开视频…</div>
    </section>
  </main>
  <script>
    (() => {
      const token = document.body.getAttribute('data-play-token') || '';
      const padded = token.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(token.length / 4) * 4, '=');
      const target = atob(padded);
      if (target.startsWith('/')) window.location.assign(target);
    })();
  </script>
</body>
</html>`;
}

function renderPublicShortLinkError(status) {
  const message = status === 410 ? '短链接已过期' : '短链接不存在或已停用';
  return `<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8" />`+
    `<meta name="viewport" content="width=device-width,initial-scale=1" />`+
    `<title>${message}</title></head><body><main><h1>${message}</h1></main></body></html>`;
}

async function serveCardPage(req, res, next) {
  try {
    const cardToken = String(req.params.cardToken || '').trim();
    if (!/^[A-Za-z0-9_-]{20,128}$/.test(cardToken)) {
      return res.status(404).type('html').send('卡片不存在');
    }

    const [rows] = await pool.execute(
      `SELECT sl.id AS short_link_id, sl.short_code, sl.card_token, sl.card_title,
              sl.card_description, sl.card_cover_url, sl.card_status,
              sl.status AS short_link_status, sl.expires_at,
              v.file_id, v.title AS video_title, v.description AS video_description,
              v.cover_url AS video_cover_url, v.status AS video_status,
              v.expires_at AS video_expires_at
       FROM short_links sl
       INNER JOIN videos v ON v.id = sl.video_id
       WHERE sl.card_token = ?
       LIMIT 1`,
      [cardToken],
    );
    const card = rows[0];
    if (!card) return res.status(404).type('html').send('卡片不存在');

    const expired = card.short_link_status !== 'active'
      || card.video_status !== 'ready'
      || (card.expires_at && new Date(card.expires_at).getTime() <= Date.now())
      || (card.video_expires_at && new Date(card.video_expires_at).getTime() <= Date.now());
    if (expired) return res.status(410).type('html').send('卡片已失效');

    if (String(req.query._shortCode || '') !== String(card.short_code)) {
      await shortLinkService.recordClickById(card.short_link_id, {
        referer: req.get('referer'),
        userAgent: req.get('user-agent'),
        ipAddress: req.ip,
      });
    }

    const redirectUrl = new URL(await buildCardPlayUrl(card.file_id, req));
    redirectUrl.searchParams.set('shortLinkId', String(card.short_link_id));
    const html = renderCardHtml(card, req, redirectUrl.toString());
    return res
      .status(200)
      .set('Cache-Control', 'public, max-age=0, must-revalidate')
      .set('Content-Security-Policy', "default-src 'none'; script-src 'unsafe-inline'; img-src https:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
      .set('Referrer-Policy', 'no-referrer')
      .set('X-Content-Type-Options', 'nosniff')
      .type('html')
      .send(html);
  } catch (error) {
    return next(error);
  }
}

async function buildPlayUrl(req, fileId, baseUrl) {
  const configuredUrl =
    baseUrl || (await getPlayPageBaseUrl()) || req.get('origin');

  if (!configuredUrl) {
    throw createHttpError(
      500,
      '缺少 PLAY_PAGE_BASE_URL 或 FRONTEND_URL，无法生成播放页地址',
      'PLAY_URL_CONFIG_ERROR',
    );
  }

  const url = new URL(configuredUrl);

  if (!/\/play\/?$/.test(url.pathname)) {
    url.pathname = `${url.pathname.replace(/\/+$/, '')}/play`;
  }

  url.searchParams.set('fileId', fileId);
  return url.toString();
}

function extractProviderClicks(stats) {
  const candidates = [
    stats?.totalClicks,
    stats?.total_clicks,
    stats?.clicks,
    stats?.click,
    stats?.count,
    stats?.pv,
  ];

  for (const value of candidates) {
    const parsed = Number(value);

    if (Number.isFinite(parsed) && parsed >= 0) {
      return Math.floor(parsed);
    }
  }

  return null;
}

async function generateShortLink(req, res, next) {
  try {
    const requestedVideoId = req.body?.videoId ?? req.body?.video_id;
    const providedLongUrl =
      typeof req.body?.longUrl === 'string' ? req.body.longUrl.trim() : '';
    let videoRows;

    if (requestedVideoId !== undefined && requestedVideoId !== null) {
      const videoId = normalizeId(requestedVideoId, 'videoId');
      [videoRows] = await pool.execute(
        `SELECT id, file_id, title, description, cover_url, business_group_id FROM videos WHERE id = ? LIMIT 1`,
        [videoId],
      );
    } else {
      let fileId;

      try {
        fileId = new URL(providedLongUrl).searchParams.get('fileId');
      } catch {
        fileId = null;
      }

      if (!fileId) {
        throw createHttpError(
          400,
          'videoId 不能为空，或 longUrl 中必须包含 fileId',
          'VALIDATION_ERROR',
        );
      }

      [videoRows] = await pool.execute(
        `SELECT id, file_id, title, description, cover_url, business_group_id FROM videos WHERE file_id = ? LIMIT 1`,
        [fileId],
      );
    }

    if (videoRows.length === 0) {
      throw createHttpError(404, '视频不存在', 'VIDEO_NOT_FOUND');
    }

    if (
      !['super_admin', 'system_admin'].includes(req.auth?.role) &&
      String(videoRows[0].business_group_id || '') !== String(req.auth?.business_group_id || '')
    ) {
      throw createHttpError(403, '只能使用本业务组的素材', 'PERMISSION_DENIED');
    }

    const videoId = String(videoRows[0].id);
    const cardToken = createCardToken();
    const longUrl = buildCardUrl(req, cardToken);
    const result = await unifiedShortLinkService.createShortLink(
      longUrl,
      req.body?.platform || 'auto',
      {
        videoId,
        cardToken,
        cardTitle: videoRows[0].title,
        cardDescription: videoRows[0].description,
        cardCoverUrl: toPublicHttpsUrl(videoRows[0].cover_url, req),
        allowFallback: req.body?.allowFallback !== false,
      },
    );

    return res.status(201).json({
      success: true,
      data: {
        ...result,
        cardToken: result.cardToken || cardToken,
        cardUrl: buildCardUrl(req, result.cardToken || cardToken),
        cardStatus: result.cardStatus || 'draft',
      },
      message: result.fallbackFrom
        ? '缩链服务不可用，已降级为自建短链'
        : '短链接生成成功',
    });
  } catch (error) {
    return next(error);
  }
}

async function selfCreateShortLink(req, res, next) {
  try {
    const videoId = normalizeId(req.body?.videoId ?? req.body?.video_id, 'videoId');
    const [videoRows] = await pool.execute(
      `SELECT id, file_id, title, description, cover_url, business_group_id,
              status, expires_at
       FROM videos WHERE id = ? LIMIT 1`,
      [videoId],
    );
    const video = videoRows[0];
    if (!video) throw createHttpError(404, '视频不存在', 'VIDEO_NOT_FOUND');
    if (
      !['super_admin', 'system_admin'].includes(req.auth?.role)
      && String(video.business_group_id || '')
        !== String(req.auth?.business_group_id || '')
    ) {
      throw createHttpError(403, '只能使用本业务组的素材', 'PERMISSION_DENIED');
    }
    if (
      video.status !== 'ready'
      || (video.expires_at && new Date(video.expires_at).getTime() <= Date.now())
    ) {
      throw createHttpError(410, '视频未就绪或已过期', 'VIDEO_NOT_AVAILABLE');
    }

    const cardToken = createCardToken();
    const longUrl = await buildPlayUrl(req, video.file_id);
    const publicOrigin = new URL(buildCardUrl(req, cardToken)).origin;
    const requestedTitle = typeof req.body?.title === 'string' ? req.body.title.trim() : '';
    const requestedDescription = typeof req.body?.description === 'string'
      ? req.body.description.trim()
      : '';
    if (requestedTitle.length > 255) {
      throw createHttpError(400, '卡片标题不能超过 255 个字符', 'VALIDATION_ERROR');
    }
    if (requestedDescription.length > 2000) {
      throw createHttpError(400, '卡片描述不能超过 2000 个字符', 'VALIDATION_ERROR');
    }

    const result = await unifiedShortLinkService.createShortLink(longUrl, 'self', {
      videoId,
      cardToken,
      cardTitle: requestedTitle || video.title,
      cardDescription: requestedDescription || video.description,
      cardCoverUrl: toPublicHttpsUrl(req.body?.coverUrl || video.cover_url, req),
      shortPathPrefix: 's',
      preferredSelfOrigin: publicOrigin,
      requirePreferredSelfOrigin: true,
      allowFallback: false,
    });

    return res.status(201).json({
      success: true,
      data: {
        ...result,
        platform: 'self',
        cardToken,
        cardUrl: result.shortUrl,
        cardStatus: result.cardStatus || 'draft',
      },
      message: '自建短链接生成成功',
    });
  } catch (error) {
    return next(error);
  }
}

async function listShortLinks(req, res, next) {
  try {
    const parameters = [];
    const conditions = [];

    const requestedVideoId = req.query.videoId ?? req.query.video_id;

    if (requestedVideoId) {
      parameters.push(normalizeId(requestedVideoId, 'videoId'));
      conditions.push('sl.video_id = ?');
    }
    if (!['super_admin', 'system_admin'].includes(req.auth?.role)) {
      parameters.push(req.auth?.business_group_id || 0);
      conditions.push('v.business_group_id = ?');
    }
    const videoFilter = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const sortDirection = String(req.query.sort || '').toLowerCase() === 'asc'
      ? 'ASC'
      : 'DESC';

    await pool.execute(
      `UPDATE short_links sl
       INNER JOIN videos v ON v.id = sl.video_id
       SET sl.status = 'expired'
       WHERE sl.status <> 'expired'
         AND ((sl.expires_at IS NOT NULL AND sl.expires_at <= NOW())
              OR v.expires_at <= NOW()
              OR v.status IN ('expired', 'deleted'))`,
    );

    const [rows] = await pool.execute(
      `SELECT sl.id, sl.video_id, v.title AS video_title, v.file_id,
              sl.short_code, sl.long_url, sl.short_url,
              sl.card_token, sl.card_title, sl.card_description,
              sl.card_cover_url, sl.card_status,
              COALESCE(sl.platform, d.platform,
                CASE WHEN d.type = 'suolink' THEN 'suolink' ELSE 'self' END
              ) AS platform,
              d.domain, sl.clicks, sl.status, sl.expires_at,
              sl.created_at, sl.updated_at
       FROM short_links sl
       INNER JOIN videos v ON v.id = sl.video_id
       INNER JOIN domains d ON d.id = sl.domain_id
       ${videoFilter}
       ORDER BY sl.created_at ${sortDirection}, sl.id ${sortDirection}`,
      parameters,
    );

    return res.json({
      success: true,
      data: rows.map((row) => ({
        ...row,
        clicks: Number(row.clicks || 0),
        external_service: cloudflareShortLinkService.isManagedDomain(row.domain)
          ? 'cloudflare'
          : null,
        card_status: row.card_status || 'draft',
        needs_regeneration: row.platform === 'suolink'
          && (!row.card_token || !/\/card\/[A-Za-z0-9_-]+(?:$|\?)/.test(row.long_url || '')),
      })),
    });
  } catch (error) {
    return next(error);
  }
}

async function getShortLinkStats(req, res, next) {
  try {
    const shortLinkId = normalizeId(req.params.id, 'shortLinkId');
    const scopeParameters = [shortLinkId];
    const scopeCondition = !['super_admin', 'system_admin'].includes(req.auth?.role)
      ? ' AND v.business_group_id = ?'
      : '';
    if (scopeCondition) scopeParameters.push(req.auth?.business_group_id || 0);
    const [rows] = await pool.execute(
      `SELECT sl.id, sl.short_url, sl.short_code, sl.provider_link_id, sl.clicks,
              d.domain,
              COALESCE(sl.platform, d.platform,
                CASE WHEN d.type = 'suolink' THEN 'suolink' ELSE 'self' END
              ) AS platform,
              SUM(CASE WHEN pl.device_type = 'mobile' THEN 1 ELSE 0 END) AS mobile_clicks,
              SUM(CASE WHEN pl.device_type = 'pc' THEN 1 ELSE 0 END) AS pc_clicks
       FROM short_links sl
       INNER JOIN videos v ON v.id = sl.video_id
       INNER JOIN domains d ON d.id = sl.domain_id
       LEFT JOIN play_logs pl
         ON pl.short_link_id = sl.id AND pl.event_type = 'redirect'
       WHERE sl.id = ?${scopeCondition}
       GROUP BY sl.id, sl.short_url, sl.short_code, sl.provider_link_id,
                sl.clicks, sl.platform, d.platform, d.type, d.domain
       LIMIT 1`,
      scopeParameters,
    );

    if (rows.length === 0) {
      throw createHttpError(404, '短链接不存在', 'SHORT_LINK_NOT_FOUND');
    }

    let totalClicks = Number(rows[0].clicks || 0);

    if (cloudflareShortLinkService.isManagedDomain(rows[0].domain)) {
      try {
        const externalStats = await cloudflareShortLinkService.getMapping(rows[0].short_code);
        const externalClicks = Number(externalStats?.clickCount);
        if (Number.isFinite(externalClicks) && externalClicks >= 0) {
          totalClicks = Math.max(totalClicks, Math.floor(externalClicks));
          await pool.execute(
            `UPDATE short_links SET clicks = GREATEST(clicks, ?) WHERE id = ?`,
            [totalClicks, shortLinkId],
          );
        }
      } catch (error) {
        logger.warn('cloudflare_statistics_cache_fallback', {
          code: error.code || 'CLOUDFLARE_STATS_FAILED',
          shortLinkId,
          cacheValue: totalClicks,
        });
      }
    }

    if (rows[0].platform === 'suolink' && process.env.SUOLINK_STATS_API_URL) {
      try {
        const providerStats = await suolinkService.getLinkStats(
          rows[0].provider_link_id || rows[0].short_code,
        );
        const providerClicks = extractProviderClicks(providerStats);

        if (providerClicks !== null) {
          totalClicks = Math.max(totalClicks, providerClicks);
          await pool.execute(
            `UPDATE short_links SET clicks = GREATEST(clicks, ?) WHERE id = ?`,
            [totalClicks, shortLinkId],
          );
        }
      } catch (error) {
        // 第三方统计不可用时仍返回数据库中的最近一次点击量。
        logger.warn('suolink_statistics_cache_fallback', {
          code: error.code || 'SUOLINK_STATS_FAILED',
          shortLinkId,
          targetPlatform: 'suolink',
          cacheValue: totalClicks,
        });
      }
    }

    return res.json({
      success: true,
      data: {
        id: rows[0].id,
        shortUrl: rows[0].short_url,
        totalClicks,
        mobileClicks: Number(rows[0].mobile_clicks || 0),
        pcClicks: Number(rows[0].pc_clicks || 0),
      },
    });
  } catch (error) {
    return next(error);
  }
}

async function toggleShortLink(req, res, next) {
  let connection;
  let transactionFinished = false;

  try {
    const shortLinkId = normalizeId(
      req.body?.shortLinkId ?? req.body?.id,
      'shortLinkId',
    );
    const platformAdmin = ['super_admin', 'system_admin'].includes(req.auth?.role);
    connection = await pool.getConnection();
    await connection.beginTransaction();

    const [rows] = await connection.execute(
      `SELECT sl.id, sl.short_code, sl.long_url, sl.short_url,
              sl.card_title, sl.card_description, sl.card_cover_url,
              sl.status, sl.expires_at, d.domain,
              v.title AS video_title, v.description AS video_description,
              v.cover_url AS video_cover_url, v.business_group_id,
              v.status AS video_status, v.expires_at AS video_expires_at
       FROM short_links sl
       INNER JOIN videos v ON v.id = sl.video_id
       INNER JOIN domains d ON d.id = sl.domain_id
       WHERE sl.id = ?${platformAdmin ? '' : ' AND v.business_group_id = ?'}
       LIMIT 1
       FOR UPDATE`,
      platformAdmin ? [shortLinkId] : [shortLinkId, req.auth?.business_group_id || 0],
    );

    if (rows.length === 0) {
      throw createHttpError(404, '短链接不存在', 'SHORT_LINK_NOT_FOUND');
    }

    const row = rows[0];
    const expired =
      (row.expires_at && new Date(row.expires_at).getTime() <= Date.now()) ||
      (row.video_expires_at &&
        new Date(row.video_expires_at).getTime() <= Date.now()) ||
      ['expired', 'deleted'].includes(row.video_status);

    if (expired) {
      await connection.execute(
        `UPDATE short_links SET status = 'expired' WHERE id = ?`,
        [shortLinkId],
      );
      await connection.commit();
      transactionFinished = true;
      throw createHttpError(409, '已过期的短链接不能重新启用', 'SHORT_LINK_EXPIRED');
    }

    const shouldEnable =
      typeof req.body?.enabled === 'boolean'
        ? req.body.enabled
        : row.status !== 'active';
    const status = shouldEnable ? 'active' : 'disabled';

    await connection.execute(
      `UPDATE short_links SET status = ? WHERE id = ?`,
      [status, shortLinkId],
    );
    await connection.commit();
    transactionFinished = true;

    if (cloudflareShortLinkService.isManagedDomain(row.domain)) {
      if (status === 'active') {
        await cloudflareShortLinkService.createMapping({
          shortCode: row.short_code,
          targetUrl: row.long_url,
          ogTitle: row.card_title || row.video_title || '视频播放',
          ogDescription: row.card_description || row.video_description || '点击查看视频素材',
          ogImage: toPublicHttpsUrl(row.card_cover_url || row.video_cover_url, req),
          ogUrl: row.short_url,
          expiresAt: row.expires_at,
        });
      } else {
        await cloudflareShortLinkService.deleteMapping(row.short_code);
      }
    }

    return res.json({
      success: true,
      data: { id: row.id, status },
      message: status === 'active' ? '短链接已启用' : '短链接已停用',
    });
  } catch (error) {
    if (connection && !transactionFinished) {
      await connection.rollback();
    }
    return next(error);
  } finally {
    connection?.release();
  }
}

async function redirectByCode(req, res, next) {
  try {
    const target = await shortLinkService.redirect(req.params.code, {
      referer: req.get('referer'),
      userAgent: req.get('user-agent'),
      ipAddress: req.ip,
    });

    if (!target?.url) {
      return res.status(404).json({
        success: false,
        data: null,
        code: 'SHORT_LINK_NOT_FOUND',
        message: '短链接不存在',
      });
    }

    const redirectUrl = new URL(target.url);
    redirectUrl.searchParams.set('shortLinkId', String(target.shortLinkId));
    if (/^\/card\/[A-Za-z0-9_-]{20,128}\/?$/.test(redirectUrl.pathname)) {
      redirectUrl.searchParams.set('_shortCode', req.params.code);
    }
    const html = renderShortLinkCardPage(target, req, redirectUrl);
    return res
      .status(200)
      .set('Cache-Control', 'public, max-age=0, must-revalidate')
      .set('Content-Security-Policy', "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src https:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
      .set('Referrer-Policy', 'no-referrer')
      .set('X-Content-Type-Options', 'nosniff')
      .type('html')
      .send(html);
  } catch (error) {
    return next(error);
  }
}

async function serveSelfShortLinkCard(req, res, next) {
  try {
    const target = await shortLinkService.resolveSelfCard(req.params.shortCode, {
      referer: req.get('referer'),
      userAgent: req.get('user-agent'),
      ipAddress: req.ip,
    });
    if (!target) {
      return res
        .status(404)
        .set('Content-Type', 'text/html; charset=UTF-8')
        .send(renderPublicShortLinkError(404));
    }

    return res
      .status(200)
      .set('Content-Type', 'text/html; charset=UTF-8')
      .set('Cache-Control', 'public, max-age=0, must-revalidate')
      .set('Content-Security-Policy', "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src https:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
      .set('Referrer-Policy', 'no-referrer')
      .set('X-Content-Type-Options', 'nosniff')
      .send(renderSelfShortLinkCardPage(target, req));
  } catch (error) {
    if (error?.status === 404 || error?.status === 410) {
      return res
        .status(error.status)
        .set('Content-Type', 'text/html; charset=UTF-8')
        .send(renderPublicShortLinkError(error.status));
    }
    return next(error);
  }
}

async function deleteSelfShortLink(req, res, next) {
  try {
    const shortLinkId = normalizeId(req.params.id, 'shortLinkId');
    const [rows] = await pool.execute(
      `SELECT sl.id, sl.short_code, sl.card_cover_url,
              COALESCE(sl.platform, d.platform,
                CASE WHEN d.type = 'suolink' THEN 'suolink' ELSE 'self' END) AS platform,
              d.domain, v.business_group_id
       FROM short_links sl
       INNER JOIN videos v ON v.id = sl.video_id
       INNER JOIN domains d ON d.id = sl.domain_id
       WHERE sl.id = ? LIMIT 1`,
      [shortLinkId],
    );
    const link = rows[0];
    if (!link) throw createHttpError(404, '短链接不存在', 'SHORT_LINK_NOT_FOUND');
    if (
      !['super_admin', 'system_admin'].includes(req.auth?.role)
      && String(link.business_group_id || '')
        !== String(req.auth?.business_group_id || '')
    ) {
      throw createHttpError(403, '只能删除本业务组的短链', 'PERMISSION_DENIED');
    }
    if (link.platform !== 'self') {
      throw createHttpError(
        409,
        '此接口仅删除自建短链，Suolink 数据未作修改',
        'SELF_SHORT_LINK_REQUIRED',
      );
    }

    if (cloudflareShortLinkService.isManagedDomain(link.domain)) {
      await cloudflareShortLinkService.deleteMapping(link.short_code);
    }
    await pool.execute('DELETE FROM short_links WHERE id = ?', [shortLinkId]);
    return res.json({
      success: true,
      data: { id: shortLinkId },
      message: '自建短链接已删除',
    });
  } catch (error) {
    return next(error);
  }
}

module.exports = {
  generateShortLink,
  selfCreateShortLink,
  listShortLinks,
  getShortLinkStats,
  toggleShortLink,
  redirectByCode,
  serveSelfShortLinkCard,
  deleteSelfShortLink,
  serveCardPage,
  renderShortLinkCardPage,
  renderSelfShortLinkCardPage,
};
