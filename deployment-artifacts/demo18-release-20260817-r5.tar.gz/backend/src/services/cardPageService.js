const crypto = require('crypto');
const { getPlayPageBaseUrl } = require('./runtimeConfigService');

const DEFAULT_CARD_BASE_URL = 'https://vod.hotwharf.com';

function createCardToken() {
  return crypto.randomBytes(32).toString('base64url');
}

function configuredBaseUrl() {
  return String(
    process.env.PUBLIC_CARD_BASE_URL
      || process.env.CARD_PAGE_BASE_URL
      || DEFAULT_CARD_BASE_URL,
  ).trim().replace(/\/+$/, '');
}

function publicBaseUrl(req) {
  const raw = configuredBaseUrl();
  try {
    const url = new URL(raw);
    if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) {
      throw new Error('invalid public card base url');
    }
    return url.toString().replace(/\/+$/, '');
  } catch {
    return DEFAULT_CARD_BASE_URL;
  }
}

function buildCardUrl(req, cardToken) {
  return new URL(`/card/${encodeURIComponent(cardToken)}`, `${publicBaseUrl(req)}/`).toString();
}

function isPrivateHostname(hostname) {
  const host = String(hostname || '').toLowerCase().replace(/^\[|\]$/g, '');
  if (host === 'localhost' || host.endsWith('.localhost') || host === '::1') return true;
  if (/^(fc|fd|fe[89ab])[0-9a-f:]*$/i.test(host)) return true;
  const match = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!match) return false;
  const octets = match.slice(1).map(Number);
  if (octets.some((octet) => octet > 255)) return true;
  const [first, second] = octets;
  return first === 0
    || first === 10
    || first === 127
    || (first === 100 && second >= 64 && second <= 127)
    || (first === 169 && second === 254)
    || (first === 172 && second >= 16 && second <= 31)
    || (first === 192 && second === 168)
    || first >= 224;
}

function toPublicHttpsUrl(value, req) {
  const raw = String(value || '').trim();
  const fallback = new URL('/wechat-share-default.png', `${publicBaseUrl(req)}/`).toString();
  if (!raw) return fallback;

  try {
    const url = new URL(raw, `${publicBaseUrl(req)}/`);
    if (
      url.protocol !== 'https:'
      || url.username
      || url.password
      || isPrivateHostname(url.hostname)
    ) return fallback;
    return url.toString();
  } catch {
    return fallback;
  }
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function inlineJsonString(value) {
  return JSON.stringify(String(value || ''))
    .replaceAll('<', '\\u003c')
    .replaceAll('>', '\\u003e')
    .replaceAll('&', '\\u0026')
    .replaceAll('\u2028', '\\u2028')
    .replaceAll('\u2029', '\\u2029');
}

async function buildPlayUrl(fileId, req) {
  let baseUrl = process.env.PUBLIC_PLAY_BASE_URL || process.env.PLAY_PAGE_BASE_URL;
  if (!baseUrl) baseUrl = await getPlayPageBaseUrl();
  if (!baseUrl) baseUrl = publicBaseUrl(req);

  const url = new URL(baseUrl);
  url.protocol = 'https:';
  if (!/\/play\/?$/.test(url.pathname)) {
    url.pathname = `${url.pathname.replace(/\/+$/, '')}/play`;
  }
  url.searchParams.set('fileId', fileId);
  return url.toString();
}

function renderCardHtml(card, req, redirectUrl) {
  const title = String(card.card_title || card.video_title || '视频播放').slice(0, 255);
  const description = String(
    card.card_description || card.video_description || '点击查看视频素材',
  ).slice(0, 2000);
  const cardUrl = buildCardUrl(req, card.card_token);
  const coverUrl = toPublicHttpsUrl(card.card_cover_url || card.video_cover_url, req);
  const target = String(redirectUrl);

  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>${escapeHtml(title)}</title>
  <meta name="description" content="${escapeHtml(description)}" />
  <link rel="canonical" href="${escapeHtml(cardUrl)}" />
  <meta property="og:type" content="website" />
  <meta property="og:title" content="${escapeHtml(title)}" />
  <meta property="og:description" content="${escapeHtml(description)}" />
  <meta property="og:url" content="${escapeHtml(cardUrl)}" />
  <meta property="og:image" content="${escapeHtml(coverUrl)}" />
  <meta property="og:image:secure_url" content="${escapeHtml(coverUrl)}" />
  <meta property="og:image:width" content="600" />
  <meta property="og:image:height" content="600" />
  <meta name="twitter:card" content="summary_large_image" />
</head>
<body>
  <main><h1>${escapeHtml(title)}</h1><p>${escapeHtml(description)}</p><a href="${escapeHtml(target)}">继续打开视频</a></main>
  <script>window.location.replace(${inlineJsonString(target)});</script>
</body>
</html>`;
}

module.exports = {
  DEFAULT_CARD_BASE_URL,
  createCardToken,
  buildCardUrl,
  buildPlayUrl,
  renderCardHtml,
  toPublicHttpsUrl,
  isPrivateHostname,
  escapeHtml,
};
