const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

test('Nginx proxies valid /s short codes to Express before the Vue fallback', () => {
  const config = fs.readFileSync(
    path.resolve(__dirname, '../../nginx/demo18.conf.template'),
    'utf8',
  );
  const routeStart = config.indexOf('location ~ "^/s/[A-Za-z0-9]{6,8}$"');
  const spaStart = config.indexOf('location / {');

  assert.notEqual(routeStart, -1, 'missing exact 6-8 character /s route');
  assert.notEqual(spaStart, -1, 'missing Vue SPA fallback');
  assert.ok(routeStart < spaStart, '/s route must be declared before the Vue fallback');

  const routeBlock = config.slice(routeStart, config.indexOf('\n    }', routeStart));
  assert.match(routeBlock, /proxy_pass http:\/\/127\.0\.0\.1:__BACKEND_PORT__;/);
  assert.doesNotMatch(routeBlock, /try_files|index\.html|rewrite/);
});
